Generative Artificial Intelligence Applications
Asliddin Tirkashev | RNU | Group 4230Z
4 November 2026

CONTENTS AND SUBMISSION

This archive contains the four available assignments and their experiment evidence.
The English PDF describes the methods, actual results, failures and limitations.

Laboratory work 01: l1/L1_profiling_Asliddin.ipynb
Laboratory work 02: l2/L2_structured_output_Asliddin.ipynb
Practice 01: p1/P1_faiss_retrieval.ipynb
Practice 02: p2/P2_rag_evaluation_Asliddin.ipynb

For separate Moodle assignment slots, use the corresponding notebook and its
results directory. Practice 02 also includes baseline.jsonl, rag.jsonl,
rag_mine.jsonl and the judge evidence under p2/results. Retain this complete
archive for the shared data, reusable code and cross-assignment configuration.
The original assignment briefs are included under assignment_briefs.

All notebook code cells were executed successfully. The model experiments were
performed on the permitted CPU track, locally on an Apple M4 Pro. They were
not measured on a Colab T4. Saved JSONL files retain the original model responses;
invalid or inaccurate responses are preserved and evaluated as failures.
Opening the notebooks displays the completed outputs without rerunning models.

REVIEW CHECKS

Run these deterministic checks without generating new model answers:
  python l1/test_reaudit.py
  python l2/test_l2_logic.py
  python p1/test_logic.py
  python p1/verify_p1.py
  python p2/test_p2_logic.py

The review independently recomputed the measured metrics and exact retrieval
rankings. Cache manifests added during this review are labelled as retrospective
checks against the unchanged original inputs. They prevent accidental reuse
after changing input logs, prompts or model settings. Original model responses,
timings and measured scores are retained. Judge records must match their source
experiment and cover every valid record before scores can be calculated.

REPRODUCTION

Use Python 3.12 and install requirements.txt in a virtual environment.
The dependency pins record the environment used for the measured work.
Install Ollama 0.17.4, then pull these exact tags:
  llama3.2:1b-instruct-q4_K_M
  llama3.2:1b-instruct-q8_0
  llama3.2:1b-instruct-fp16
  qwen3:0.6b-q4_K_M
  qwen3:1.7b-q4_K_M
  nomic-embed-text:latest

Keep the archive's l1, l2, p1, p2 and data folders together. Run notebook cells
in order, using the CPU defaults. Set GENAI_DATA to data/chaoscorp if required.
The notebooks retain Colab setup instructions for a new independent run.

For new local CPU measurements, start a dedicated server in a terminal:
  OLLAMA_HOST=127.0.0.1:11435 OLLAMA_NUM_PARALLEL=2 ollama serve

In another terminal, activate the Python environment and set:
  export GENAI_TRACK=CPU
  export GENAI_NUM_GPU=0
  export GENAI_RUNTIME="local CPU"
  export OLLAMA_URL=http://127.0.0.1:11435
  export GENAI_OLLAMA_URL=http://127.0.0.1:11435

From the root of this archive, the core runners are:
  python l1/l1_experiment.py --url http://127.0.0.1:11435
  python l2/l2_experiment.py
  python p1/run_p1.py
  python p2/run_p2.py --stage arms
  python p2/run_p2.py --stage judges
  python p2/run_p2.py --stage sample

Inspect the ten sampled judge decisions and record the review before selecting
the judge version. After writing an improvement_plan.json from observed errors:
  python p2/run_p2.py --stage improvement
  python p2/run_p2.py --stage judges
  python p2/run_p2.py --stage analyse

The runners reuse existing matching completed records. Use fresh result folders
to measure a different model, dataset, prompt or runtime. Environment variables:
GENAI_L1_RESULTS, GENAI_L2_RESULTS, GENAI_P2_RESULTS. Practice 01 accepts --results.
P2 reads the selected retriever from p1/results/p1_best_config.json; use
GENAI_P1_BEST_CONFIG if selecting a separately measured Practice 01 experiment.
The judge-review file records the ten checked decisions and the chosen version.

RESULTS AND AVAILABILITY

The verification manifest lists execution counts, experiment counts and SHA-256
file hashes. The full results directories contain settings and original evidence.
P1 search latency excludes the separately reported service-extraction cost.
P2 uses 12 sorted incidents, k=3 and the CPU budget of 200 generated tokens.

Practice 04 displayed TBD without an assignment brief at the availability check.
Practice 03 was not visible. Neither has been counted as completed.
No Moodle upload or grade is claimed by this archive.
