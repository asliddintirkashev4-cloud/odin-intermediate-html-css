# P1: FAISS Retrieval Mini-Project — Finding the Right Runbook Section

**Course:** GenAI Applications · **Weight:** 12% · **Weeks:** 4–5 · **Individual**
**Environment:** Colab + Ollama (embedding model `nomic-embed-text`), `faiss-cpu`, Python
**Data:** Chaos Corp data pack:
- `runbooks/` and `policies/`: 16 documents (10 service runbooks and 3 distractor documents with sections `s1_overview` … `s6_escalation`; 3 policies with sections `s1_…` … `s3_…`),
- `incidents_test.json`: 25 incidents; each has `gold.service_name` and `gold.gold_sections`.


> **Setup, GPU/CPU track and saving results:** see *Getting started* (Moodle) and run the `00_setup_colab.ipynb` cells first. Write "GPU track" or "CPU track" at the top of your notebook; the CPU track uses the reduced sizes listed there.

## Goal
Build a retriever that returns the runbook sections an on-call engineer needs for an incident, and **prove how good it is** with retrieval metrics against gold labels. A good retriever here is the foundation for P2 (RAG).

## Part 1 — Ingest and chunk (code; Parts 1–3 together 30 pts)
1. Load every document. Keep each section's `doc_id`, `service_name` and `section_id`.
2. Implement **two chunking strategies**:
   - **C1, fixed-size:** ~500 characters, ~50 characters overlap, ignoring section boundaries.
   - **C2, structure-aware:** one chunk per section; if a section exceeds ~800 characters, split it with overlap.
3. Every chunk carries metadata `chunk_id`, `doc_id`, `service_name` and `section_ids`. `section_ids` lists every section the chunk overlaps; for C1 compute it from character offsets.
4. Report the number of chunks and the mean/min/max chunk length for C1 and C2.

## Part 2 — Index and retrieve (code)
1. Embed the chunks with `nomic-embed-text` via Ollama (`POST /api/embed`). Normalize the vectors and use `faiss.IndexFlatIP` (cosine similarity).
2. Implement `retrieve(query_text, k=5, service_filter=None) -> list[dict]`, returning chunks with metadata and score.
3. **Metadata filter:** when `service_filter` is given, search only that service's runbook plus the three policies. Obtain the service from the incident log with your Lab 2 extractor. If it returns `UNKNOWN`, do not filter. Do **not** use `gold.service_name` as the filter: the gold labels are for evaluation only.

## Part 3 — Evaluate (code)
Use each incident's `raw_log` as the query. `gold.gold_sections` lists entries like `runbook_authserver#s2_symptoms` (doc_id `#` section_id). A retrieved chunk is **relevant** if it comes from the gold runbook (`doc_id`) and its `section_ids` overlap `gold.gold_sections`. Implement in code:

| Metric | Definition |
|---|---|
| Hit@1, Hit@3 | share of incidents with ≥1 relevant chunk among the top 1 / top 3 |
| MRR@5 | mean of 1/rank of the first relevant chunk (0 if none in the top 5) |
| Section recall@5 | share of an incident's gold sections covered by the top 5, averaged |
| Distractor@3 | share of incidents where a distractor document (`runbook_paymentgateway_v1_deprecated`, `runbook_payment_reporting`, `guide_platform_k8s_operations`) appears in the top 3 |

## Part 4 — Your own chunk size (15 pts) and the controlled comparison (20 pts)
Choose **your own** C1 chunk size and overlap (not 500/50), write your expectation before running, and add it as `C1_own` (with and without the filter): 6 configurations in total. Then answer with your numbers. The questions are in the notebook, YOUR TURN 6.
Run 4 configurations: {C1, C2} × {no filter, service filter}. Report one table with all metrics and the mean retrieval latency, then answer:
- Which single change helped more: the chunking or the filter?
- Did the filter ever **hurt**, e.g. when the extractor picked the wrong service (H4/H5 incidents)?

## Part 5 — Failure analysis (30 pts)
Analyse the **5 weakest incidents** of your best configuration (ranked by hit@3, then MRR, then section recall; the notebook lists them). For each, show the query, the top-3 chunks (doc, section, score) and the gold sections, and give a one-line diagnosis. Example categories:
- alias not understood,
- multi-service log,
- distractor wins,
- chunk mixes two sections,
- noisy text.

Propose one concrete fix and, if time allows, test it.

## Clarity (5 pts) and reproducibility (up to −5 pts if missing)
Clarity: tables visible, every answer cell filled in, the GPU/CPU track stated.

Pin the package versions, fix seeds and print the model tags. The notebook must run top to bottom.

## Submit
One `.ipynb`. It is your report: code, tables, failure cases and ~300 words of discussion.
