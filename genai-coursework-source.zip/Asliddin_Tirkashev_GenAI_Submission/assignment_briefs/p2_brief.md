# P2: RAG Triage with Evaluation — Does Retrieval Make the Answers Better?

**Course:** GenAI Applications · **Weight:** 12% · **Weeks:** 5–6 · **Individual**
**Builds on:** P1 (your best retriever configuration), Lab 2 (structured output), your Lab 1 model card.
**Data:** Chaos Corp data pack:
- `incidents_test.json` (25 incidents with gold `severity`, `service_name`, `cause_id`, `escalation_targets`),
- the corpus from P1,
- `schema_v2.json` (triage output).


> **Setup, GPU/CPU track and saving results:** see *Getting started* (Moodle) and run the `00_setup_colab.ipynb` cells first. Write "GPU track" or "CPU track" at the top of your notebook; the CPU track uses the reduced sizes listed there.

## Goal
Produce a full triage record (`schema_v2.json`) for each incident, with and without retrieval. Measure whether RAG improves **correctness** and **grounding**, not just fluency.

## Part 1 — Two pipelines (code; Parts 1–2 code together 30 pts)
Both pipelines get the same system prompt: the role, `policy_severity.md`, `policy_escalation.md` and the schema. Both use schema-constrained output (Lab 2, strategy C) plus the word-limit checks in code.
- **Baseline:** incident log only, no retrieved documents.
- **RAG:** the top-k chunks from your best P1 configuration (k = 4), each labelled `[doc_id | chunk_id]` in the prompt. `citations` must reference chunks given in the prompt.

Implement them with LangChain: a prompt template → `ChatOllama(...).with_structured_output(...)`, plus your retriever.

## Part 2 — Automatic evaluation (code) and checking the judge (10 pts)
Implement every metric in code over the 25 incidents:

| Metric | How |
|---|---|
| Severity accuracy, service accuracy | exact match with gold |
| Escalation exact match | `set(pred) == set(gold.escalation_targets)` |
| Escalation micro-F1 | over the four targets |
| Cause accuracy | an **LLM judge** maps your free-text `probable_cause` to one of the service's cause IDs (from `services.json`) or `other`, using structured output `{cause_id, justification}`; compare with `gold.cause_id` (skip incidents whose gold cause is null) |
| Citation validity | share of outputs where every cited `chunk_id` was in the retrieved set and its `doc_id` matches (RAG only) |
| Step grounding | an **LLM judge** decides for each recommended step whether the cited chunks support it, with structured output `{supported: bool, evidence_quote}`; report the share of supported steps |
| Word-limit compliance, latency | % compliant outputs; mean seconds per incident |

**Judge validity (required):** label 10 judge decisions yourself (5 cause, 5 grounding) and report the agreement. If the agreement is below 8/10, improve the judge prompt and say what you changed.

## Part 3 — Results and error analysis (25 pts)
1. One table comparing Baseline and RAG on all metrics.
2. An error table for every incident where RAG is wrong on severity, service or escalation: incident, field, predicted, gold, `hard_case_tags`, retrieved chunks (doc/section), diagnosis. Was it a **retrieval** failure (gold sections not retrieved) or a **generation** failure (retrieved but ignored or misread)?
3. Show 2 incidents where RAG clearly helped and 1 where it hurt, with the evidence.

## Part 3B — Your own improvement (15 pts)
Choose **one** change (number of chunks k, the service filter, or one extra prompt rule), write your prediction **before** running, and measure it as a third pipeline `rag_mine` against baseline and RAG (notebook Step 4B).

## Part 4 — Discussion (15 pts, ≈300 words) and clarity (5 pts)
1. Which field benefited most from retrieval, and why does that fit what the runbooks contain?
2. How much do retrieval failures (P1 metrics) explain the remaining RAG errors?
3. What do you trust less, the cause judge or the grounding judge, and why?
4. One change you would make next (reranking, a larger k, query rewriting, a better prompt), with the metric you expect it to move.

## Submit
One `.ipynb` with:
- both pipelines,
- the stored outputs (JSONL),
- the evaluation code, the tables, the judge-validity check and the discussion.
