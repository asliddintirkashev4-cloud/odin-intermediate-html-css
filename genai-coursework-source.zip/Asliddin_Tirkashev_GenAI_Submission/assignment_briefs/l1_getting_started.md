# GenAI Applications — Getting started with the practices

All practices (Lab 1, Lab 2, P1–P4) run in **Google Colab** with **Ollama** (local open models, no paid API keys). They all use the same data: the **Chaos Corp data pack**.

## 1. What to download from Moodle
| File | What it is |
|---|---|
| `chaoscorp_data_pack_v2.zip` | All data: incident logs with gold labels, runbooks, policies, schema, safety test cases (you upload it in the setup notebook) |
| `L1_profiling.ipynb`, `L2_structured_output.ipynb` | **Guided notebooks for Lab 1 and Lab 2**: open in Colab and run top to bottom (setup included) |
| `00_setup_colab.ipynb` | Setup only. Copy its cells to the top of your notebook for P1–P4 |
| `brief.md` of the practice | The task description |

## 2. The data pack: just upload it when asked
1. Download `chaoscorp_data_pack_v2.zip` from Moodle to your computer. Do not unzip it.
2. When the notebook asks for it (**Step 0.4** in the Lab 1/Lab 2 notebooks, section 3 in `00_setup_colab.ipynb`), a **"Choose Files"** button appears. Select the zip; the notebook checks it and extracts it to `/content/chaoscorp`.
3. That is all you need: by default (`USE_DRIVE = False`) the notebook does not touch your Google Drive. You upload the zip once per session, and results are lost when the session ends, so download what you need before closing.
4. **Optional, recommended for long practices (P2–P4):** set `USE_DRIVE = True` in the settings cell (**Step 0.2**; section 1 in `00_setup_colab.ipynb`). Colab then asks once for permission to access your Drive, saves a copy of the zip in `MyDrive/genai_course/` (later sessions do not ask for the upload again) and keeps your results there, where they survive disconnects.

## 3. Choose a runtime: GPU track or CPU track
In Colab: **Runtime → Change runtime type → T4 GPU**.

| | GPU track (T4 available) | CPU track (no GPU available) |
|---|---|---|
| Main model | your Lab 1 model card choice (max 7–8B, e.g. `qwen3:4b-q4_K_M`) | `qwen3:1.7b-q4_K_M` (fallback: `qwen3:0.6b-q4_K_M`) |
| Embedding model | `nomic-embed-text` | `nomic-embed-text` (also fast on CPU) |
| Settings | `num_ctx` 4096 | `num_ctx` 2048, `num_predict` ≤ 200, `think: false` |
| Dataset sizes | as in the brief | reduced, see table below |

The free Colab tier sometimes offers no GPU. Then you can:
- try again later,
- use **Kaggle Notebooks** (free GPU quota, about 30 hours per week; Ollama installs the same way),
- or work on the **CPU track**.

Write **"GPU track"** or **"CPU track"** at the top of your notebook. The CPU track is not penalised: it is graded on the same rubric, with the reduced sizes below.

| Practice | CPU-track reduction |
|---|---|
| Lab 1 | Exp. A with `llama3.2:1b-instruct` q4_K_M / q8_0 / fp16; Exp. B with `qwen3` 0.6b / 1.7b; 3 timed runs instead of 5; Part 3 with 1 vs 2 requests |
| Lab 2 | full (15 incidents) |
| P1 | full (embeddings are cheap) |
| P2 | first 12 test incidents (sorted by `incident_key`); k = 3 chunks |
| P3 | 10 of your 18 samples |
| P4 | 6 attacks + 6 benign cases (first by `case_id`) + 10 normal incidents |

## 4. Every session: run Step 0 first
In the Lab 1 and Lab 2 notebooks, **Step 0** does the setup (in `00_setup_colab.ipynb` the same cells are sections 0–5):

| Step | What it does |
|---|---|
| 0.1 | installs the Python packages and **restarts the runtime on purpose**: Colab reports a "crash"; that is expected, continue with 0.2 |
| 0.2 | settings: `TRACK` (GPU/CPU) and `USE_DRIVE` |
| 0.3 | checks the GPU |
| 0.4 | asks for the data pack zip and extracts it. With `USE_DRIVE = True` it uses the copy on Drive and asks only the first time |
| 0.5 | installs and starts Ollama |
| 0.6 | loads the helper functions and downloads your model |
| 0.7 | **Lab 2 only:** use your model from Lab 1. It is found automatically if your Lab 1 results are on Drive; otherwise type its name |

This takes about 3–5 minutes. Models are downloaded again each session, which is fast in Colab.

**Lab 1 → Lab 2:** Lab 2 uses the model you chose in Lab 1 (your *model card*). If you do not use Drive, **write down the model name** at the end of Lab 1.

## 5. Protect your results against disconnects
Colab disconnects after inactivity or after a few hours. To lose nothing:
- Keep your **results on Drive** (`USE_DRIVE = True`): `MyDrive/genai_course/results/<practice>/`.
- **Lab 1 and Lab 2:** the notebooks already save every finished item immediately and skip finished items when you run a cell again. After a disconnect, run Step 0 again, then continue with the step where you stopped.
- **P1–P4 (your own code):** write results **one record per line** (JSONL) as soon as each item is finished (helper `append_jsonl`), and skip items already in the results file (helper `done_keys`). Both helpers are in `00_setup_colab.ipynb`.
- Download your final notebook (**File → Download .ipynb**) and submit it to Moodle together with the results files the brief asks for.

## 6. Data pack contents
| File | Used in |
|---|---|
| `incidents_original10.json` | Lab 1 |
| `incidents_dev.json` (15) | Lab 2 |
| `incidents_test.json` (25) | P1, P2, P4 |
| `runbooks/*.md` (13), `policies/*.md` (3) | P1, P2, P4 (Lab 2: severity guide) |
| `services.json`, `schema_v2.json` | Lab 2, P2 |
| `adversarial.json` (24) | P4 |
| `p3_datasets/<code>/` | P3 (your subfamily) |

**Gold labels** (`gold` fields) are for **evaluating** your system only. Never put them into prompts, filters or features. Doing so is data leakage and is treated as a serious error in grading.
