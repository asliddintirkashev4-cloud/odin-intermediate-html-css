# Lab 1 (v2): The Engine Room — Profiling Local LLMs

**Course:** GenAI Applications · **Type:** formative (ungraded) · **Time:** ~3 h
**Environment:** Google Colab, T4 GPU (≈15 GB usable VRAM), Ollama, Python 3.10+


> **Work in the guided notebook `L1_profiling.ipynb` (Moodle):** it contains the setup, ready-made code, the ✏️ YOUR TURN tasks and the answer cells. This brief is the reference description.
>
> **Setup, GPU/CPU track and saving results:** see *Getting started* (Moodle) and run the `00_setup_colab.ipynb` cells first. Write "GPU track" or "CPU track" at the top of your notebook; the CPU track uses the reduced sizes listed there.

## Goal
Measure how **quantization** and **model size** change memory, speed and answer quality, using measurements you can trust, then choose the model you will use in the rest of the course (your **model card**).

You will run two controlled experiments. In each one only **one** thing changes:

| Experiment | What changes | What stays fixed |
|---|---|---|
| A — Quantization | `llama3.2:3b-instruct-q4_K_M` → `-q8_0` → `-fp16` | model, prompt, settings |
| B — Size | `qwen3:1.7b-q4_K_M` → `qwen3:4b-q4_K_M` → `qwen3:8b-q4_K_M` | family, quantization, prompt, settings |

---

## Part 0 — Setup (15 min)
1. Start Ollama in Colab as in the course setup notebook, then check that it responds: `!ollama list`.
2. Pull the six models of experiments A and B (about 20 GB in total; start the downloads early).
3. Download the Chaos Corp data pack and load `chaoscorp/incidents_original10.json` (10 incident logs with gold labels).

## Part 1 — Measure correctly (30 min)
Write one function `run(model, prompt)` that calls the Ollama API (`POST /api/chat`, `"stream": false`) with **fixed settings** for every call:
```python
options = {"temperature": 0, "seed": 42, "num_predict": 256, "num_ctx": 4096}
# for qwen3 models also send "think": false  (no hidden reasoning tokens)
```
Take the numbers from Ollama's response, **not** from your own stopwatch or your own token counting:

| Metric | Formula from the response fields |
|---|---|
| Decode speed (tok/s) | `eval_count / (eval_duration / 1e9)` |
| Prompt processing (tok/s) | `prompt_eval_count / (prompt_eval_duration / 1e9)` |
| Time to first token, warm (s) | `prompt_eval_duration / 1e9` |
| Load time (s) | `load_duration / 1e9` (first call only) |

**Memory and the GPU check:** after loading each model, run `!ollama ps`.
- Record the **SIZE** column.
- Check the **PROCESSOR** column. It must say **100% GPU**. If it shows a CPU share, part of the model was offloaded to the CPU and your speed numbers are not GPU numbers: note it in the table and do not compare that row as a GPU result.
- Also record `nvidia-smi` memory before and after loading.

**Unload between models** with `!ollama stop <model>`, or send `"keep_alive": 0` on the last call. Check with `ollama ps` that nothing is loaded before the next model.

## Part 2 — Experiments A and B (60 min)
For every model:
1. Do one warm-up call and discard it.
2. Do **5 timed calls** with the standard prompt:
   *"Explain to a new on-call engineer, in at most 120 words, why a read replica can show higher latency than the primary database."*
3. Do a **quality check**: for each of the 10 incidents, ask the model for the severity only (answer exactly `High`, `Medium` or `Low`; give it the severity guide `policies/policy_severity.md`) and compare with `gold.severity`.

Fill one table per experiment (mean ± standard deviation over the 5 runs):

| Model tag | Quant | Params | SIZE (ollama ps) | PROCESSOR | VRAM Δ nvidia-smi (GB) | Decode tok/s | Prompt tok/s | Warm TTFT (s) | Load (s) | Severity accuracy (/10) |
|---|---|---|---|---|---|---|---|---|---|---|

## Part 3 — Parallel requests (30 min)
Restart Ollama with `OLLAMA_NUM_PARALLEL=4`, using the `ollama` process handle from the setup notebook:
```python
import os, subprocess, time
ollama.terminate(); ollama.wait()
ollama = subprocess.Popen(["ollama", "serve"], env={**os.environ, "OLLAMA_NUM_PARALLEL": "4"},
                          stdout=open("/content/ollama.log", "w"), stderr=subprocess.STDOUT)
time.sleep(5)
```
With your preferred model, send **1** request, then **4 simultaneous** requests (use `concurrent.futures.ThreadPoolExecutor`). Report:
- the per-request decode tok/s,
- the **aggregate** tok/s (sum of tokens / wall-clock time),
- the VRAM in each case.

## Part 4 — Analysis (≈250 words) and model card
1. **Quantization:** how much memory and speed did q4_K_M save compared with fp16, and did severity accuracy change? Is the trade-off worth it for this task?
2. **Size:** where does accuracy stop improving enough to justify the slower speed?
3. **Serving:** from your Part 3 numbers, estimate how many users with one request every 20 s this GPU could serve within a 5 s response target. State your assumptions.
4. **Model card:** name the model tag you will use in Labs 2–4 and P1–P4, with its tok/s, VRAM and accuracy.

**Optional — what CPU offload looks like:** run `qwen3:8b-q4_K_M` again with `options={"num_gpu": 10, ...}`. This keeps only 10 layers on the GPU and puts the rest on the CPU. Look at the PROCESSOR column in `ollama ps` and at the decode speed, and explain in two sentences what happened. (Do not pull a model larger than the GPU in Colab: spilling into the 12.7 GB of system RAM can crash the runtime.)

## Submit
One `.ipynb` with:
- the `run()` function,
- both experiment tables, the parallel-request results and the analysis,
- your model card,
- an extra LangChain cell: the same prompt sent via `langchain_ollama.ChatOllama` to your chosen model.
