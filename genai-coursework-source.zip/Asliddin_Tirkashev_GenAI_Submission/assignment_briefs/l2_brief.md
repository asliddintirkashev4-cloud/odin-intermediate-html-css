# Lab 2 (v2): Taming the Beast — Structured Extraction You Can Measure

**Course:** GenAI Applications · **Type:** formative (ungraded) · **Time:** ~3 h
**Prerequisite:** Lab 1 — use the model from your model card.
**Data:** Chaos Corp data pack, `incidents_dev.json` (15 incident logs with gold labels).


> **Work in the guided notebook `L2_structured_output.ipynb` (Moodle):** it contains the setup, ready-made code, the ✏️ YOUR TURN tasks and the answer cells. This brief is the reference description.
>
> **Setup, GPU/CPU track and saving results:** see *Getting started* (Moodle) and run the `00_setup_colab.ipynb` cells first. Write "GPU track" or "CPU track" at the top of your notebook; the CPU track uses the reduced sizes listed there.

## Goal
Turn messy incident logs into a **valid and correct** JSON record, and measure the difference between three ways of getting there. *Valid* (it parses and matches the schema) is not the same as *correct* (the values match the gold labels). This lab measures both.

## Target record
```python
from typing import Literal, Optional
from pydantic import BaseModel, Field

class Extraction(BaseModel):
    incident_id: Optional[int] = Field(description="ID in the log, or null if there is none")
    severity: Literal["High", "Medium", "Low"]
    service_name: Literal["PaymentGateway_v2", "EmailNotifier", "AuthServer", "DatabaseCluster",
                          "Frontend_React", "UserProfileDB", "SearchEngine", "payment-processor",
                          "InventoryAPI", "Recommendations-AI", "UNKNOWN"]
    summary: str = Field(description="at most 12 words")
```
Give the model the severity guide (`policies/policy_severity.md`) and the service list with aliases (`services.json` → `service_name`, `aliases`). Severity must follow the guide, including the upward overrides. Aliases must be mapped to the canonical name.

## Three strategies (same prompt content, same model, temperature 0)

**A — Ask & Repair (retry logic).** Ask for JSON in the prompt. Validate with `Extraction.model_validate_json`. On failure, send the validation error back ("Your JSON was invalid: <error>. Return only corrected JSON."). At most 3 retries.

**B — JSON mode.** Call Ollama with `format="json"`. This guarantees *syntactically* valid JSON, but not your schema. Validate with Pydantic exactly as in A, and use the same repair loop when validation fails.

**C — Schema-constrained.** Make the model's decoding follow your schema:
```python
from langchain_ollama import ChatOllama
llm = ChatOllama(model=MODEL, temperature=0, reasoning=False).with_structured_output(Extraction, method="json_schema")  # reasoning=False = no qwen3 thinking
```
or pass `format=Extraction.model_json_schema()` to the Ollama API. Still validate the result, and still check the 12-word limit in code: the schema cannot enforce word counts.

## Measure
For each strategy on all 15 incidents, log every call (attempt number, latency, raw output, error). Then fill:

| Metric | A Retry | B JSON mode | C Schema |
|---|---|---|---|
| Schema-valid on first try (%) | | | |
| Schema-valid after retries (%) | | | |
| Mean calls per incident | | | |
| Mean latency per incident (s), all attempts | | | |
| `incident_id` accuracy (%) | | | |
| `severity` accuracy (%) | | | |
| `service_name` accuracy (%) | | | |
| Summary ≤ 12 words (%) | | | |

Accuracy compares a field with `gold.<field>`. Use the strategy's final output (after retries); an output that is still invalid counts as wrong.

**Stress test (Step 5B in the notebook):** repeat all three strategies with the tiny model `qwen3:0.6b-q4_K_M` (results in a separate folder) and compare with your model.

Then make an **error table** for every wrong field: `incident_key`, field, predicted, gold, `gold.hard_case_tags`, your one-line explanation.

## Analysis (≈250 words)
1. Did B and C reduce retries compared with A? Did they change latency?
2. Which strategy had the best **accuracy** (not validity)? Are errors concentrated on certain hard-case tags (H1–H5)?
3. Find one case where the output was *valid but wrong*. What would catch it in production?
4. Which strategy would you use in a backend batch job, and which in a user-facing chatbot? Why?

## Submit
One `.ipynb` with:
- the three pipelines,
- the call log (as a DataFrame),
- the metrics table, the error table and the analysis.
