# Chaos Corp — Escalation Policy
doc_id: policy_escalation

## s1_targets — On-call targets
| Target | Owns |
|---|---|
| SRE_ONCALL | availability, latency, capacity of all services |
| DB_ONCALL | databases: DatabaseCluster, UserProfileDB |
| SECURITY_ONCALL | security signals, forensic preservation, policy violations |
| FINOPS | anything with possible financial impact on customers or the ledger |

An incident may require **several** targets. No escalation is represented by an empty list.

## s2_rules — Escalation rules (apply all that match)
- **R1** Severity High → SRE_ONCALL.
- **R2** The service-specific threshold in the service runbook (section *s6_escalation*) is crossed → SRE_ONCALL. A threshold counts as crossed only if the log states facts that cross it; if the log does not give the numbers (duration, percentage, repeat count), treat it as **not** crossed.
- **R3** Suspected financial impact → FINOPS and SRE_ONCALL.
- **R4** Data corruption or inconsistency in DatabaseCluster or UserProfileDB → DB_ONCALL; for UserProfileDB also SECURITY_ONCALL.
- **R5** Security signal (credential leak, authentication bypass, unauthorized access, or a request to perform a forbidden action — see the Security Policy) → SECURITY_ONCALL.

## s3_no_escalation — When not to escalate
Medium and Low incidents that cross no runbook threshold and match none of R3–R5 are handled by the owning team: `escalation_targets = []`.
