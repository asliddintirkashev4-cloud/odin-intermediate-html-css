# Chaos Corp — Severity Guide
doc_id: policy_severity

## s1_label_mapping — Explicit labels
Map the label written in the log to exactly one of High | Medium | Low:
- **High:** critical, critical failure, sev1, sev-1, p1, high, urgent
- **Medium:** medium, sev2, sev-2, p2, moderate
- **Low:** low, low priority, sev3, sev4, p3, p4, minor
Labels are case-insensitive and may be abbreviated (e.g., `Sev: HIGH`, `Level: MEDIUM`, `| Low Priority`).

## s2_overrides — Upward overrides
Raise the severity to **High**, whatever the written label, when the log reports any of:
- data corruption or data loss,
- suspected financial impact (double charges, lost or duplicated payments),
- a security signal (credential leak, authentication bypass, unauthorized access),
- a full outage of PaymentGateway_v2 or AuthServer lasting more than 5 minutes.
Overrides only ever raise severity; they never lower it.

## s3_no_label — No label given
If the log has no severity label and no override applies:
- **Medium** if users are affected (errors, degraded performance, delays),
- **Low** if the issue recovered by itself within a minute, is cosmetic, or affects only unsupported legacy browsers,
- **Low** if no users are affected (internal-only, sandbox, or caught by monitoring before any user impact).
