# Chaos Corp data pack v2 — GenAI Applications

| File | Content |
|---|---|
| incidents_original10.json | 10 incident logs with gold labels (Lab 1) |
| incidents_dev.json | 15 incident logs with gold labels (Lab 2) |
| incidents_test.json | 25 incident logs with gold labels (P1, P2, P4) |
| runbooks/*.md | 13 documents (10 service runbooks + 3 distractors), 6 sections each |
| policies/*.md | severity guide, escalation policy, security policy |
| services.json | services, aliases, cause IDs, escalation thresholds |
| schema_v2.json | triage output schema (P2) |
| adversarial.json | 12 attacks + 12 benign look-alikes (P4) |
| p3_datasets/<code>/ | P3 dataset (25 samples + tool data) per subfamily |

Gold labels (`gold` fields) are for evaluation only: never use them in prompts, filters or features.
