# AuthServer Incident Runbook
doc_id: runbook_authserver
service_name: AuthServer

## s1_overview — Overview
AuthServer provides login, session, and token operations for every internal and customer-facing service. It validates credentials against UserProfileDB, issues signed tokens, and enforces session state. Watch the Grafana "auth-service-overview" dashboard for login success rate, p95 latency, active sessions, token validation queue depth, and pod memory. Key alerts cover repeated OOMKilled events, rising p95 above baseline, failed token validation spikes, and anomalous geographic login patterns. Treat any outage as company-wide because downstream services depend on token checks.

## s2_symptoms — Symptoms
Common signs include slow logins, p95 latency above 800 ms, elevated 5xx responses, and token validation errors from dependent services. Pod-level symptoms include OOMKilled restarts, steady RSS growth, and repeated restarts in kubectl get pods -n auth. Traffic symptoms include unexpected successful logins from unknown locations, failed MFA steps, and spikes in /login and /validate endpoints. Check the "auth-latency" dashboard, error budget burn, and UserProfileDB connection pool saturation. Capture timestamps, affected tenants, and whether symptoms correlate with key rotation jobs.

## s3_fast_triage — Fast Triage
Start with kubectl get pods -n auth -o wide and kubectl describe pod <pod> to confirm OOMKilled or crash loops. Query Grafana for p95 login latency, token validation retries, and memory per pod. Run kubectl logs deployment/auth-server --tail=200 to look for key loading failures, signature mismatches, or UserProfileDB timeouts. If retries are high, inspect the validation queue backlog and recent client retry storms. For suspicious logins, pull audit events by user, IP range, and token audience. Preserve raw logs and dashboard screenshots before taking mitigation actions.

## s4_safe_mitigation — Safe Mitigation
Prefer reversible actions. Roll pods to clear leaked memory when memory growth is confirmed, accepting temporary disruption. Scale replicas +1 to reduce per-pod load during sustained latency. Enable heap profiling if supported and preserve logs for later analysis. If signing-key rotation looks incomplete, re-run the key rotation job in dry-run mode before retrying production execution. Verify that UserProfileDB connections recover and token validation errors decrease. Record each action with timestamp, owner, and rollback note.

## s5_root_causes — Root Causes
auth_memory_leak appears as gradual RSS increase and OOMKilled without traffic change; check heap profiles and long-lived token caches. auth_token_retries shows high validation retry rates, queue backlog, and repeated client attempts after transient failures; correlate with upstream retry policies. auth_key_rotation manifests as signature mismatch errors, mixed old/new key usage, or failed rotation job completion; inspect rotation job logs and key version distribution. Distinguish causes by timing: leaks grow over hours, retries spike with client traffic, and key issues align with rotation windows.

## s6_escalation — Escalation
Escalate to SRE_ONCALL when OOMKilled repeats within 1 hour or when severity is High. Attach pod names, memory graphs, p95 latency, token validation error rates, and mitigation actions taken. Escalate to SECURITY_ONCALL for any sign of credential leak or authentication bypass, including unexpected successful logins from unknown locations, impossible travel, or anomalous token issuance. Include audit excerpts, affected accounts, source IPs, and preserved logs. Begin security escalation immediately when indicators appear.
