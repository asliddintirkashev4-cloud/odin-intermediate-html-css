# Platform Kubernetes Operations Guide
doc_id: guide_platform_k8s_operations
service_name: ALL

## s1_overview — Overview
This guide provides generic Kubernetes operating steps for Chaos Corp services. It covers routine pod inspection, controlled restarts, deployment scaling, event review, and log preservation. It is intended for platform engineers and service owners who need repeatable actions during incidents. The guidance is deliberately service-agnostic, so it does not diagnose payment, reporting, or business logic failures. Use it alongside the relevant service runbook. Commands assume standard cluster access, RBAC permissions, and the internal observability stack. Always record the namespace, workload name, and time window before making changes so the action can be correlated with metrics and logs.

## s2_symptoms — Symptoms
Platform symptoms appear across workloads:
- Pods stuck in CrashLoopBackOff, ImagePullBackOff, Pending, or Terminating.
- Deployments showing unavailable replicas or stalled rolling updates.
- HPA oscillating or nodes reporting pressure conditions.
Services may lose endpoints, experience increased 5xx responses, or show elevated p99 latency without application code changes. Logs may be truncated, missing, or duplicated after node replacement. Alerting can fire for kube-state-metrics, container resource limits, or ingress controller health. Because these signs are common, correlate them with a specific namespace and workload before concluding that the platform itself is degraded.

## s3_fast_triage — Fast Triage
Begin with kubectl get pods -n <namespace> -o wide to identify abnormal workloads and node placement.
- Run kubectl describe pod <name> -n <namespace> to inspect events, probes, and volume mounts.
- Check kubectl get events -n <namespace> --sort-by=.lastTimestamp for scheduling, image pull, or eviction signals.
Compare kubectl get deployment, hpa, and replicaset to see desired versus ready replicas. Review Prometheus panels for CPU, memory, restarts, and network errors. Pull logs with kubectl logs --previous when a container crashed. Confirm node health with kubectl get nodes and describe node. Preserve the output of these commands in the incident before restarting or scaling anything.

## s4_safe_mitigation — Safe Mitigation
Use the least disruptive action that matches the observed failure.
- For a single unhealthy pod, recreate the pod so the controller replaces it, then watch the new pod reach Ready.
- If many pods are unhealthy, reduce deployment replicas briefly only if the service supports reduced capacity, then restore the replica count.
For resource pressure, increase CPU or memory limits through the approved deployment template and let the rollout proceed gradually. Preserve logs by exporting kubectl logs output and enabling persistent log collection before node maintenance. Record every command, replica change, and rollout hash. Avoid broad namespace-wide actions unless the platform on-call confirms cluster-level impact.

## s5_root_causes — Root Causes
- Node resource exhaustion: the node runs out of allocatable CPU or memory, causing pods to be evicted. Recognise this via node pressure events, OOMKilled containers, and scheduler failures.
- Image pull failure: registry authentication, tag typo, or network egress blocks prevent startup. Look for ImagePullBackOff and pull secrets in the pod spec.
- Probe misconfiguration: liveness or readiness thresholds are too aggressive, causing restarts or endpoint removal. Check probe timing, failure counts, and endpoint flap patterns.
- Storage or CSI issues: volumes fail to attach or mount, leaving pods Pending. Inspect PVC status, CSI driver events, and node disk errors.
- Network policy or ingress faults: traffic is blocked or misrouted. Identify dropped connections, wrong Service selectors, and ingress controller errors.

## s6_escalation — Escalation
Follow policy_escalation for any platform action that affects multiple namespaces, core infrastructure, or customer-facing availability. Page the Platform SRE on-call and the cluster owner when node, registry, DNS, ingress, or storage components are involved. Attach the affected namespace, pod names, kubectl describe output, event timeline, Prometheus metric links, log excerpts, and the exact mitigation performed. If the issue remains unresolved after a controlled restart or scaling change, escalate to the next platform tier with a concise summary of what was tried, what changed, and what evidence remains. Include rollout hashes and node identifiers to speed up diagnosis.
