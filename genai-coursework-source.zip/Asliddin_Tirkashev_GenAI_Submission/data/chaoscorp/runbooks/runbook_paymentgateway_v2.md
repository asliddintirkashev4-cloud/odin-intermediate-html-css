# PaymentGateway_v2 checkout and payments incident runbook
doc_id: runbook_paymentgateway_v2
service_name: PaymentGateway_v2

## s1_overview — Overview
PaymentGateway_v2, also called payment gateway, PG v2, checkout API, or payments API, is the public checkout and payments API used by the web shop and mobile app. It depends on AuthServer, payment-processor, and UserProfileDB. Operators should watch the Payments Overview dashboard, HTTP 5xx ratio for /checkout and /payments, p95 latency, pod restarts, and retry counters. Use kubectl get pods -n payments to confirm rollout state and kubectl logs deployment/paymentgateway-v2 for request IDs. Keep change notes near deploys because provider settings and downstream timeouts often drive incidents.

## s2_symptoms — Symptoms
Typical symptoms include HTTP 5xx on /checkout and /payments, customer reports of failed checkout, increased pod restarts, and elevated p95 latency on payment endpoints. Check the Payments Error Rate and Latency dashboards first, then inspect kubectl get events -n payments and kubectl top pods -n payments. Look for 502/504 spikes, AuthServer 401/403 bursts, payment-processor timeout counters, and UserProfileDB slow query graphs. Preserve request IDs from access logs so later triage can correlate the same transaction across services.

## s3_fast_triage — Fast triage
Start by confirming blast radius: compare /checkout and /payments success rates against the last hour baseline. Run kubectl get pods -n payments to see CrashLoopBackOff or OOMKilled states, then kubectl logs deployment/paymentgateway-v2 --tail=100 for provider errors. Query the recent deploy list and note whether the first bad minute matches a release. Check AuthServer token validation latency and payment-processor p95 from the Upstream Health panel. Capture three representative request IDs and attach screenshots of the error-rate graph before making any mitigation decision.

## s4_safe_mitigation — Safe mitigation
If the error budget is burning, roll pods with kubectl rollout restart deployment/paymentgateway-v2 -n payments and watch the next two minutes. If capacity looks tight, scale replicas +1 temporarily with kubectl scale deployment/paymentgateway-v2 -n payments --replicas=3. If one upstream is unstable, enable the circuit breaker for that dependency rather than retrying aggressively. If errors began immediately after a deploy, roll back the last deploy. Always capture request IDs and preserve logs for 60 minutes. Keep provider credentials and security controls unchanged during the incident.

## s5_root_causes — Root causes
Recognise pg_env_misconfig when a new deploy changes a payment-provider environment variable and provider-specific errors appear immediately; inspect env values in the pod spec and deploy diff. Recognise pg_downstream_timeout when payment-processor p95 rises, HTTP 504s increase, and timeout counters climb; check the Upstream Health panel and network dashboards. Recognise pg_auth_slowdown when AuthServer token validation latency spikes, 401/403 rates rise, and checkout latency follows; compare AuthServer CPU, GC, and connection pool metrics.

## s6_escalation — Escalation
If this is high severity or checkout has been down for more than 5 minutes, page SRE_ONCALL. Attach the Payments Overview screenshot, affected /checkout and /payments paths, request IDs, deploy timestamp, and current mitigation state. If there is suspected financial impact, such as double charges or lost payments, page SRE_ONCALL and FINOPS. Include customer-visible failure estimates, transaction identifiers where available, and evidence that retries did not resolve the issue.
