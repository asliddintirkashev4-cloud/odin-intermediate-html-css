# UserProfileDB incident runbook
doc_id: runbook_userprofiledb
service_name: UserProfileDB

## s1_overview — Overview
UserProfileDB stores user accounts and profile data on the DatabaseCluster storage layer, with periodic snapshots used for recovery. Use this runbook when integrity alarms fire, checksum mismatches appear, or a restore or rollback has already begun. Monitor the ProfileDB_Integrity Grafana dashboard for checksum failures, replication lag, long-running transactions, and storage I/O errors. Confirm cluster health with kubectl get pods -n database -l app=userprofiledb and review PostgreSQL logs for FATAL or PANIC entries around the alert window.

## s2_symptoms — Symptoms
Common symptoms include data corruption detected in user tables, checksum mismatches reported by integrity checks, and emergency restore or rollback activity triggered by operators. Watch for sudden increases in constraint violations, unreadable rows, unexpected nulls in required profile fields, and elevated I/O wait on DatabaseCluster volumes. The ProfileDB_Integrity dashboard may show failing page checksums, WAL replay errors, and query latency spikes on the users table. Capture table names, row identifiers, transaction IDs, and the first alert timestamp.

## s3_fast_triage — Fast triage
First determine whether corruption is localized to one table or cluster-wide. Run psql -h userprofiledb-primary -U reader -d profiledb -c 'SELECT relname, n_live_tup FROM pg_stat_user_tables ORDER BY n_live_tup DESC;' to identify hot tables and compare recent checksum reports. Check the DatabaseCluster storage dashboard for bad sector, volume, or node alerts. Review psql query logs for bulk updates, migrations, or long-running transactions. If replication lag is high, note the LSN and WAL segment names for later forensic review.

## s4_safe_mitigation — Safe mitigation
If corruption is suspected, move the affected database into read-only mode using the approved freeze-writes procedure, then identify the corrupted tables and the earliest reliable time window. Preserve WAL files, query logs, and audit trails for forensic review. Restore the impacted data from the latest known-good snapshot, following the snapshot restore checklist, and rerun consistency checks afterward. Verify checksums, row counts, and critical user profile queries before returning service to normal operation. Document every state change with timestamps.

## s5_root_causes — Root causes
Root causes to distinguish: updb_bad_migration occurs when a faulty schema migration leaves inconsistent constraints, indexes, or transformed data; recognize it by correlation with a recent migration job and checksum failures in migrated columns. updb_storage_fault occurs when DatabaseCluster storage corrupts pages; recognize it through bad block alerts, repeated page checksum failures, and errors tied to specific nodes or volumes. updb_unauthorized_write occurs when an unauthorized or anomalous bulk write changes many rows; recognize it through audit log spikes, unfamiliar service identities, and unusual update volume outside maintenance windows.

## s6_escalation — Escalation
Escalation is mandatory for any corruption. Any corruption: page DB_ONCALL and SECURITY_ONCALL immediately, attaching the ProfileDB_Integrity dashboard link, checksum failure details, affected tables, WAL segment list, and suspected time window. High severity: also page SRE_ONCALL when customer impact, broad data unavailability, or repeated restore attempts occur. Keep the incident bridge updated with mitigation actions, restore progress, forensic preservation status, and verification results until the database is stable.
