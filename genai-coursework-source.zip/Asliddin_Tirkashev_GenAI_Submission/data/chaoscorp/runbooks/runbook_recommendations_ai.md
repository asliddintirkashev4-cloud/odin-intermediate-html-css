# Recommendations-AI incident runbook
doc_id: runbook_recommendations_ai
service_name: Recommendations-AI

## s1_overview — Overview
Recommendations-AI serves personalized product recommendations to storefronts and mobile apps. It consumes features from the feature store and executes model inference on GPU inference nodes. Teams may refer to it as recommender, recs, or recommendation model. Its primary risk is silent degradation: users receive fewer relevant products while synthetic checks still pass. Incident response should compare latency, fallback usage, model version behavior, and feature-store responsiveness.

## s2_symptoms — Symptoms
Typical symptoms are increasing inference latency, no hard errors but a degraded user experience, and increased fallback to the popular-items list. Users may see generic recommendations, lower click-through, or slower product pages. Dashboards often show p95 latency rising while request error rate remains flat. Fallback counters increase when the recommender times out, returns empty results, or fails internal quality checks before serving personalized output.

## s3_fast_triage — Fast triage
Check the Recommender dashboard for p50/p95 latency, fallback rate, GPU utilization, and feature-store request latency. Inspect pods with kubectl top pods -n recs -l app=recommendations-ai and review recent deployment events with kubectl rollout history deployment/recommendations-ai -n recs. On GPU nodes, capture nvidia-smi output for memory and utilization. Verify feature-store p95 and timeout counts. Compare current model version against the previous stable release and note any traffic split changes.

## s4_safe_mitigation — Safe mitigation
Apply low-risk mitigations first. Scale replicas +1 temporarily to relieve pressure on saturated inference nodes. If a newly deployed model version is confirmed as the regression, roll back to the last known-good model version and verify fallback rate improves. Where supported, enable caching for frequent recommendation requests to reduce feature-store load and repeat inference work. After each step, watch p95 latency, fallback percentage, and GPU saturation for at least thirty minutes before declaring stabilization.

## s5_root_causes — Root causes
Identify rec_model_regression when latency or relevance metrics worsen immediately after a model deploy, while infrastructure remains healthy. rec_gpu_saturation appears as high GPU utilization, memory pressure, or queuing on inference nodes, often with rising p95 latency across replicas. rec_feature_store_latency is visible when feature-store p95 or timeout rate rises before recommender degradation. Use deploy timelines, per-version latency charts, node metrics, and feature-store traces to separate model, compute, and upstream dependency causes.

## s6_escalation — Escalation
Escalate to SRE_ONCALL when latency has doubled for more than 30 minutes, or when the incident is rated High severity. Page the SRE on-call engineer with the latency dashboard, fallback-rate chart, GPU utilization, feature-store latency, model version, and mitigation actions taken. Include user impact such as degraded personalization or slow product pages. If the condition resolves before the threshold, record near-miss details and continue monitoring for recurrence.
