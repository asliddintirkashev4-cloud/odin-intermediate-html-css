# DatabaseCluster Incident Runbook
doc_id: runbook_database_cluster
service_name: DatabaseCluster

## s1_overview — Overview
DatabaseCluster is the shared PostgreSQL environment supporting orders, inventory, and search indexing. It consists of a primary and read replicas, with storage volumes and replication as core dependencies. Monitor the "db-cluster-health" dashboard for replication lag, lock waits, slow query rate, disk IO wait, and connection saturation. Alert thresholds focus on read-replica latency spikes, replication lag beyond target, and sustained high IO wait. Because many services share this cluster, triage should separate application pressure from storage or replication problems early.

## s2_symptoms — Symptoms
Typical symptoms include read-replica latency spikes, elevated lock contention, slow queries, replication lag, and high disk IO wait. In Grafana, watch replica lag seconds, p95 query latency, active backend count, and IO wait percent. In psql, look for long-running statements, blocked processes, and unresponsive replicas. Application teams may report order writes slowing, inventory reads stalling, or search indexing falling behind. Note which node is affected, whether the primary remains healthy, and whether symptoms follow batch jobs, index maintenance, or traffic bursts.

## s3_fast_triage — Fast Triage
Begin with the "db-cluster-health" dashboard to identify the affected node and time window. Use psql on the replica to inspect pg_stat_activity, pg_locks, and pg_stat_replication for lag, blocking chains, and idle transactions. Capture top slow queries with EXPLAIN plans where safe, and compare disk IO wait across nodes. Check storage volume utilization and recent maintenance activity. If a replica is degraded, determine whether read traffic can be shifted to healthier replicas. Preserve query samples, lock snapshots, and dashboard exports before making changes.

## s4_safe_mitigation — Safe Mitigation
Use least-disruptive controls first. Identify top slow queries before changing anything, and capture query text, plan, and duration. If index bloat or a missing index is confirmed, schedule a re-index in the maintenance window or add a missing index via the migration process. If a replica is degraded, fail over read traffic to healthy replicas while preserving primary write path. Monitor lock contention and replication lag after each step. Keep changes reversible and record exact commands, owners, and observed recovery.

## s5_root_causes — Root Causes
db_missing_index appears as full scans, high CPU, and slow queries on large tables; recognise it through plan output showing Seq Scan and low row estimates. db_long_queries appears as long-running statements holding locks, blocked sessions, and elevated wait events; recognise it through pg_stat_activity durations and lock chains. db_disk_io appears as high IO wait on one replica, slow reads, and storage saturation; recognise it through node-specific IO metrics and slow replica response. Compare symptoms across primary and replicas to isolate the failing component.

## s6_escalation — Escalation
Escalate to DB_ONCALL for any data inconsistency or corruption sign, such as checksum failures, divergent replica results, or unexplained missing rows. Attach affected tables, query results, replication status, and storage metrics. If severity is High, also page SRE_ONCALL for cluster-wide impact, severe latency, or replication failure. Include dashboard links, psql snapshots, lock information, and mitigation actions already performed. Keep the primary write path stable while specialists investigate.
