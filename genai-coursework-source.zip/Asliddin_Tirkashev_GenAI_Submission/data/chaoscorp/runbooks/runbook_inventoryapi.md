# InventoryAPI incident runbook
doc_id: runbook_inventoryapi
service_name: InventoryAPI

## s1_overview — Overview
InventoryAPI publishes current stock levels and availability for storefronts. It reads from DatabaseCluster, caches hot SKU records, and relies on a sync job to reconcile cached values with source-of-truth rows. The service is commonly called inventory, stock service, or inventory service. During incidents, focus on cache freshness, synchronization health, and user-visible oversell signals rather than raw API availability alone. Use the runbook when stock state looks stale or inconsistent.

## s2_symptoms — Symptoms
Common signs include stock counts differing between cache and database, items displayed as available while actually out of stock, and repeated sync job failures. Operators may see elevated 5xx or timeout rates on inventory endpoints, rising cache miss ratios, or customer reports of failed checkout due to unavailable stock. Dashboards often show a widening gap between cached quantity and database quantity, especially after promotions, restocks, or failed background runs.

## s3_fast_triage — Fast triage
Start by checking the InventoryAPI dashboard for mismatch rate, cache hit ratio, and sync job success. Query recent job history with kubectl get jobs -n inventory -l app=inventory-sync --sort-by=.status.startTime and inspect logs for skipped batches. Compare sample SKUs using psql -c 'SELECT sku, qty FROM inventory.stock LIMIT 20' against cache snapshots. Review invalidation queue depth with rabbitmqctl list_queues name messages. Confirm whether TTL settings changed recently.

## s4_safe_mitigation — Safe mitigation
Prefer reversible actions. Trigger the manual sync job in safe mode so it reconciles without overwriting uncertain stock states. If stale cache persists, temporarily reduce the cache TTL for affected SKU prefixes and watch the mismatch trend. After each action, monitor the mismatch rate, cache/database delta, and checkout error rate for at least one full sync cycle. Record before-and-after metric snapshots and note any promotions, deploys, or queue backlog that could influence recovery.

## s5_root_causes — Root causes
Recognize inv_sync_failed when the sync job is missing, failing, or skipping batches, often with queue backlog and unchanged cache timestamps. inv_ttl_too_long appears when entries remain readable far beyond expected expiry, usually after a config change or missing TTL default. inv_lost_invalidation shows stale cache despite successful sync, with dropped or unprocessed invalidation events in the message queue. Cross-check deploy notes, TTL configuration, and queue consumer lag to distinguish the three.

## s6_escalation — Escalation
Escalate to SRE_ONCALL when the cache/database mismatch affects more than 2% of SKUs. Page the SRE on-call engineer immediately and attach the mismatch dashboard, SKU sample list, sync job logs, queue depth, TTL settings, and mitigation timeline. Include customer impact such as oversell or checkout failures. If the threshold is below 2%, continue monitoring and document the incident; escalate only if the affected SKU share crosses the stated limit.
