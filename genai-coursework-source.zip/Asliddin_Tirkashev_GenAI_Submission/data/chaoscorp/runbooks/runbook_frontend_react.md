# Frontend_React incident runbook
doc_id: runbook_frontend_react
service_name: Frontend_React

## s1_overview — Overview
Frontend_React is the customer-facing React web app delivered through the Chaos Corp CDN, with builds from the frontend build pipeline and checkout calls to PaymentGateway_v2. Use this runbook when users report broken pages, missing assets, or post-deploy regressions. Check the Frontend_CDN Grafana dashboard for error rate, asset 404s, TTFB, and browser matrix alerts. Inspect recent deploys with kubectl rollout history deployment/frontend-react -n customer-web and compare artifact hashes against the release notes.

## s2_symptoms — Symptoms
Typical symptoms include CSS or JavaScript assets not loading for specific browsers, stale bundles remaining after a deploy because CDN cache headers were not refreshed, and blank pages with console errors. Look for spikes in asset 404s, mixed content warnings, hydration failures, and PaymentGateway_v2 checkout failures concentrated on one region or browser class. Search the frontend error dashboard for 'Uncaught TypeError', 'Failed to fetch', and cache-control anomalies. Capture the affected URL, browser version, and asset hash before triage.

## s3_fast_triage — Fast triage
Start by confirming whether the issue affects supported browsers only, legacy browsers only, or all users. Query the CDN dashboard for cache HIT ratio and origin pull rate by asset path. Test a known good URL with curl -I https://cdn.chaoscorp.example/assets/app.js and compare the ETag to the latest build manifest. Check kubectl get events -n customer-web and the build pipeline status for failed or partial releases. If PaymentGateway_v2 errors appear, check its latency panel before blaming the UI.

## s4_safe_mitigation — Safe mitigation
If stale or mismatched assets are confirmed, purge the CDN for the affected asset paths using the approved CDN control plane, then verify fresh ETags at edge PoPs. If the problem is widespread across supported browsers, roll back the last frontend deploy through the build pipeline and confirm the previous bundle serves correctly. If only legacy browsers are affected, publish a limited browser support notice in the status page and customer comms. Record every action in the incident timeline with timestamps and owner names.

## s5_root_causes — Root causes
Root causes to distinguish: fe_bad_build means the last deploy shipped a broken artifact, visible as new syntax errors, missing chunks, or failing smoke tests immediately after release. fe_cdn_cache means CDN cache headers serve stale or mismatched assets, visible as old ETags persisting after deploy and origin pulls remaining low. fe_unsupported_browser means an unsupported legacy browser triggers polyfill or feature gaps, visible only in older browser telemetry. Compare release notes, asset hashes, and browser matrix to isolate the cause.

## s6_escalation — Escalation
Escalate according to impact scope. Supported browsers affected: page SRE_ONCALL immediately and attach the Frontend_CDN dashboard link, affected asset hashes, browser matrix screenshot, and deploy identifier. Legacy-only problems: no escalation is required; document the browser limitation and monitor for spread. If the incident becomes severe, keep the incident channel updated with mitigation steps, verification results, and customer communication status.
