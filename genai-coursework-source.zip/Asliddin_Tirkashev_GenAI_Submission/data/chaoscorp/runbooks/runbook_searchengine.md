# SearchEngine Incident Runbook
doc_id: runbook_searchengine
service_name: SearchEngine

## s1_overview — Overview
SearchEngine provides product search across Chaos Corp storefronts and relies on DatabaseCluster as the index source. It runs as a Kubernetes stateful set with index and query pods. The primary dashboards are search-slo, search-node-health, and search-traffic. Key metrics include p95 search latency, 5xx rate, index refresh lag, node CPU/memory, and open file descriptors. Operators should treat this service as customer-facing and prioritize restoring query availability before deep forensics.

## s2_symptoms — Symptoms
Common incidents begin with short downtime and auto-restart events in the search cluster. Users see bursts of 5xx on /search, /suggest, and /autocomplete endpoints, while dashboards show elevated error ratios and dropped queries. Some searches return slow responses or empty result sets even when DatabaseCluster is healthy. Alerts often appear together: pod restarts, memory spikes, file descriptor exhaustion, and autoscaler lag. Check Grafana search-slo and kubectl get pods -n search to correlate timing.

## s3_fast_triage — Fast Triage
Start by confirming blast radius. Run kubectl get pods -n search -o wide and kubectl describe pod <pod> to identify restarts, OOMKilled status, and readiness failures. Query Prometheus for sum(rate(http_requests_total{namespace="search",code=~"5.."}[5m])) and max(process_open_fds{namespace="search"}). Inspect Grafana search-node-health for memory, FD, and autoscaler current replicas. If DatabaseCluster is degraded, note index refresh lag before changing search capacity. Capture the last restart timestamps and the first 5xx burst window.

## s4_safe_mitigation — Safe Mitigation
Prefer reversible actions. First check node health and restart reasons using kubectl logs --previous <pod> and the restart reason field. Verify autoscaling rules in the search-hpa resource and confirm replica count can follow traffic. If OOM restarts are observed, increase the memory limit slightly for affected pods, then watch memory usage and restart frequency. Capture logs around the restart event with kubectl logs --timestamps --previous and export them to the incident channel. Avoid broad changes until the trigger is clear.

## s5_root_causes — Root Causes
Three common root causes drive SearchEngine incidents. search_oom occurs when a node memory limit is too low; recognise it via OOMKilled pod status, memory near limit in Grafana, and restart loops. search_fd_limit appears when the file descriptor limit is reached; look for process_open_fds at ulimit, socket errors, and failed index connections. search_traffic_spike happens when traffic exceeds autoscaling limits; identify it with sudden QPS growth, HPA max replicas reached, and sustained 5xx before pods scale out.

## s6_escalation — Escalation
Escalate to SRE_ONCALL when repeated downtime occurs within 30 minutes, or when the incident is classified High severity. Page SRE_ONCALL immediately and attach the incident ID, Grafana links for search-slo and search-node-health, kubectl describe output, restart timestamps, and log excerpts. Include the suspected trigger, current mitigation, and customer impact. Continue updates every 15 minutes until ownership is accepted.
