# PaymentGateway_v1 Deprecated Runbook
doc_id: runbook_paymentgateway_v1_deprecated
service_name: PaymentGateway_v1

## s1_overview — Overview
PaymentGateway_v1 was decommissioned in 2025. This document preserves legacy operating notes for the retired VM-based gateway, including host-level configuration review and legacy VM restart steps. It is historical context only. Current transactional routing belongs to PaymentGateway_v2, and v2 incidents must use the v2 runbook and current dashboards. The v1 stack had separate credentials, older certificates, and manual host edits. Keep these notes for audit, migration comparison, and understanding why certain v2 controls exist. Treat any v1 alert as a decommissioning artifact unless evidence shows residual traffic or an open dependency.

## s2_symptoms — Symptoms
Typical v1 noise appears after cutover:
- Stale alerts for legacy VM heartbeat or expired certificates.
- Absent payment-gateway-v1 metrics in Prometheus.
- Old Nginx access logs with zero requests.
- DNS lookups returning NXDOMAIN or a parked endpoint.
Financial dashboards should show no v1 authorization volume, but audit trails may retain archived transactions. Watch for mixed references in tickets where v1 and v2 terminology overlap, especially card network identifiers, settlement files, and webhook retries. Confirm whether the symptom is truly v1 before touching anything.

## s3_fast_triage — Fast Triage
Confirm the incident is tied to the retired v1 environment.
- Check the service inventory for PaymentGateway_v1 status.
- Verify no active load balancer targets remain.
- Query the legacy VM console for power state and last boot time.
- Inspect archived Nginx and app logs for timestamps after the decommission date.
Review the v2 gateway dashboard to ensure live traffic is healthy and that no v1 endpoints are referenced by customers. If any current transaction appears affected, treat it as a v2 incident. Capture screenshots of the inventory, alert payload, and residual DNS records for the escalation packet.

## s4_safe_mitigation — Safe Mitigation
Safe handling is containment, not recovery.
- Freeze changes to the retired VM.
- Preserve logs, configuration snapshots, and alert payloads.
- Identify any caller using a residual v1 endpoint and route the team to v2 support.
Record the exact hostname, port, certificate expiry, and last successful request timestamp. Notify the platform owner that the asset is decommissioned and confirm whether the monitoring alert should be suppressed. Attach evidence to the incident record. If the v1 system is merely noisy, mark the ticket as decommissioning cleanup and schedule follow-up with the SRE team.

## s5_root_causes — Root Causes
- Legacy VM retirement: the host is powered off or removed from inventory, causing heartbeat and log-collection alerts. Recognise this by empty cloud console activity and no running processes.
- Host-only configuration: v1 settings existed only on the server file system, so a missing file or expired key produces confusing errors. Look for manual config paths and absent version control.
- Mistaken v2 association: operators apply v1 steps to v2 because names resemble each other. Spot this when v2 dashboards remain healthy but v1 tooling is opened.
- Residual DNS or proxy entries: old CNAMEs still point to retired addresses. Verify with DNS lookup and access logs.

## s6_escalation — Escalation
Escalate according to policy_escalation whenever the retired v1 environment appears connected to live customer traffic, a security boundary, or financial reconciliation. Page the Platform SRE on-call and the Payments Engineering lead if any current authorization, capture, or refund path is uncertain. Attach the decommission date, VM console state, alert payload, residual DNS records, v2 dashboard screenshot, and ticket history. If the issue is purely stale monitoring, escalate as low severity for alert cleanup and request confirmation that no v1 dependencies remain in production inventories or runbooks.
