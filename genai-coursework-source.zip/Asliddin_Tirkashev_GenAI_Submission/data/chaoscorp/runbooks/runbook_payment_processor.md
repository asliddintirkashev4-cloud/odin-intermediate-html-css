# payment-processor Incident Runbook
doc_id: runbook_payment_processor
service_name: payment-processor

## s1_overview — Overview
payment-processor is a background worker that settles payments consumed from the payments queue and writes results to the ledger database. It runs as a Kubernetes deployment with multiple consumer replicas. Core dashboards are payments-worker-slo, payments-queue-depth, and ledger-integrity. Watch queue lag, consumer throughput, duplicate detection counters, ledger write errors, and settlement success rate. Because the service touches money movement, operators should assume financial impact until reconciliation proves otherwise.

## s2_symptoms — Symptoms
Incidents usually surface as duplicate transaction processing alerts, ledger mismatches, or growing settlement backlog. Users may not notice immediately, but finance tooling reports unmatched postings, repeated settlement IDs, or delayed credit entries. Dashboards often show queue depth rising, consumer processing time spiking, and duplicate counters increasing. Check Grafana payments-queue-depth and ledger-integrity, then compare consumer logs against the payments queue message IDs to find repeated processing windows.

## s3_fast_triage — Fast Triage
First determine whether duplicates are increasing or stable. Run kubectl get pods -n payments-worker and kubectl logs <pod> | grep -i 'duplicate|idempotency' to locate repeated message IDs. Query Prometheus for sum(rate(queue_messages_processed_total{job="payment-processor"}[5m])) and max(queue_depth{queue="payments"}). Inspect the ledger database with psql -c "SELECT message_id, count(*) FROM ledger_entries GROUP BY message_id HAVING count(*) > 1 LIMIT 20;" to confirm mismatches. Note consumer timeouts, queue redelivery events, and any recent downstream outage before making changes.

## s4_safe_mitigation — Safe Mitigation
Contain the issue first by stopping queue consumers to prevent further duplicates using the approved consumer pause control. Switch to manual approval mode so pending settlements wait for review. Reconcile ledger entries and preserve audit logs by exporting affected message IDs, consumer timestamps, and ledger row references. Re-enable consumers only after idempotency is confirmed for the affected batch, then monitor duplicate counters and queue lag for at least one full processing cycle.

## s5_root_causes — Root Causes
Three causes commonly explain payment-processor incidents. pp_missing_idempotency appears when requests lack idempotency keys; recognise it by repeated settlement attempts with no stable key in request metadata. pp_redelivery occurs after queue redelivery following a consumer timeout; look for ack timeouts, duplicate message IDs, and processing gaps. pp_retry_storm follows a downstream failure; identify it with a sudden burst of retries, rising queue depth, and correlated errors from the failing dependency.

## s6_escalation — Escalation
Escalate to SRE_ONCALL and FINOPS whenever there is any suspected financial impact. Page both SRE_ONCALL and FINOPS immediately, attaching the incident ID, duplicate transaction examples, ledger mismatch query results, queue depth charts, and consumer logs. Include the estimated affected amount, whether consumers are paused, and manual approval status. Provide updates every 15 minutes until both owners acknowledge and a recovery plan is agreed.
