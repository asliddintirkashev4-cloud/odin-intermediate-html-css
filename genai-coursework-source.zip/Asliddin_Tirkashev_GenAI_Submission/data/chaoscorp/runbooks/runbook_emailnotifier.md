# EmailNotifier transactional email delivery incident runbook
doc_id: runbook_emailnotifier
service_name: EmailNotifier

## s1_overview — Overview
EmailNotifier, known as the email service, notifier, or mailer, sends transactional emails such as password resets, receipts, and notifications from a message queue. It depends on the external SMTP provider and the message queue. Watch the Mailer Throughput dashboard, queue depth, consumer lag in minutes, SMTP 4xx/5xx responses, and delivery success rate. Use kubectl get pods -n mailer to inspect consumers and kubectl logs deployment/email-notifier for SMTP response codes. Queue health and provider status pages are the first places to look.

## s2_symptoms — Symptoms
Common symptoms are password-reset emails delayed, queue depth spikes, consumer lag measured in minutes, and SMTP 4xx/5xx responses from the external provider. Check the Mailer Queue Depth and Delivery Failure dashboards, then run kubectl get pods -n mailer and kubectl top pods -n mailer to spot stuck or overloaded consumers. Look for redelivery spikes, visibility-timeout expirations, and provider throttling notices. Preserve queue message IDs and SMTP response bodies where available so the incident can be traced end to end.

## s3_fast_triage — Fast triage
First establish whether the problem is queue-side or provider-side. Compare queue depth against the previous day and check consumer lag in minutes on the Mailer Lag panel. Run kubectl get pods -n mailer to identify missing, restarting, or CPU-throttled consumers, then kubectl logs deployment/email-notifier --tail=200 for SMTP 4xx/5xx patterns. Check the external SMTP provider status page and rate-limit headers. Note the oldest undelivered message ID and the first time lag crossed the alert threshold before choosing a mitigation.

## s4_safe_mitigation — Safe mitigation
If consumers are insufficient for load, scale them up by 1 or 2 temporarily with kubectl scale deployment/email-notifier -n mailer --replicas=4. Drain the backlog gradually and monitor retry rate, dead-letter arrivals, and SMTP 4xx/5xx volume. If messages are redelivered because visibility expires, increase the visibility timeout cautiously. If the primary SMTP provider is down, switch to the secondary SMTP provider. Keep queued messages and recipient data unchanged during the incident.

## s5_root_causes — Root causes
Recognise email_smtp_outage when the external SMTP provider returns 4xx/5xx responses, its status page shows degradation, and delivery success falls sharply; check provider response codes and latency. Recognise email_consumer_lag when queue depth grows while consumer count is low, lag is measured in minutes, and pods show high CPU or queue-processing saturation; compare consumer throughput to inflow. Recognise email_rate_limit when sending rate approaches or exceeds the configured limit, retry storms appear, and provider throttle headers increase.

## s6_escalation — Escalation
If email delays are longer than 15 minutes, page SRE_ONCALL. Attach the Mailer Queue Depth and Delivery Failure dashboard views, consumer lag trend, queue message IDs, SMTP response samples, provider status page link, and any mitigation already applied. Include the first delayed message timestamp and the current backlog size. If customer-facing password resets or receipts remain blocked, note the affected user journeys in the incident channel.
