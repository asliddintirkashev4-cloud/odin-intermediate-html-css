# payment-reporting Incident Runbook
doc_id: runbook_payment_reporting
service_name: payment-reporting

## s1_overview — Overview
payment-reporting is a nightly batch service that aggregates authorization, capture, refund, and settlement data into finance-ready reports. It runs after end-of-day cutoffs and publishes artifacts to the reporting warehouse and shared storage. The service is separate from real-time payment processing, although it reuses similar vocabulary such as charge IDs, merchant codes, and gateway events. Its health depends on upstream ledgers, queue consumers, and scheduled jobs. This runbook covers late reports, partial outputs, and reconciliation gaps. It is not a substitute for transactional payment runbooks and should not be used to investigate live authorization failures.

## s2_symptoms — Symptoms
Common symptoms include:
- Reports arriving after the finance deadline.
- Row counts below expected totals.
- Missing refund or dispute sections.
- Stale last-run timestamps in the batch dashboard.
Users may see blank PDFs, empty CSV exports, or reconciliation files that fail validation. Queue depth for report-build jobs can climb while worker pods remain idle. Upstream ledger tables may show delayed partitions, and downstream BI dashboards can display yesterday's data. Alerts often reference report IDs, dataset names, or warehouse table freshness rather than live payment latency. Check whether the issue affects only one report family or the entire nightly batch.

## s3_fast_triage — Fast Triage
Open the payment-reporting batch dashboard and identify the latest successful run, failed run, and expected completion window.
- Check the scheduler for task states, retry counts, and sensor waits.
- Inspect the report queue for message age and consumer lag.
- Use psql to compare row counts in the staging schema against the prior day.
Inspect worker logs for database connection errors, permission denials, schema mismatches, or timeout messages. Review warehouse freshness metrics for source ledger tables. If source data is late, note the partition watermark. If source data is fresh but the report is incomplete, focus on transform tasks, queue consumers, and output writers. Save the run ID and dashboard links early.

## s4_safe_mitigation — Safe Mitigation
Prefer rerunning the failed report task from its last known good checkpoint.
- Pause downstream distribution if partial artifacts were published, then republish after validation.
- Clear stuck sensors only when the source watermark confirms readiness.
- Increase worker concurrency temporarily if queue age exceeds threshold, while watching memory and warehouse load.
Validate output checksums and row counts before notifying finance. If a schema change is suspected, compare the current DDL snapshot with the previous release and coordinate with data engineering. Keep all raw inputs intact. Document the mitigation, affected report IDs, and the validation result in the incident. Use the scheduler UI to track the rerun until the report reaches a completed state.

## s5_root_causes — Root Causes
- Source ledger lag: upstream transaction tables are not complete by batch start. Recognise this by late partition watermarks and missing recent charge IDs in staging.
- Queue consumer stall: report-build workers stop consuming jobs, leaving messages aged. Look for zero consumer throughput with rising queue depth and idle CPU.
- Transform schema mismatch: a field rename or type change breaks SQL or Python transforms. Spot tracebacks referencing columns, null casts, or unexpected enum values.
- Warehouse throttling: concurrent loads exceed quota, causing slow inserts. Identify long-running queries, lock waits, and warehouse queue metrics.
- Distribution failure: artifacts are built but not copied to finance storage. Check export job status and object storage listing timestamps.

## s6_escalation — Escalation
Escalate according to policy_escalation when financial reporting deadlines are at risk, reconciliation discrepancies affect reported revenue, or report data integrity cannot be validated. Page the Data Platform on-call and Finance Reporting owner if the issue blocks month-end close or regulatory reporting. Attach the batch run ID, scheduler task graph, queue depth chart, warehouse freshness dashboard, sample report diff, and validation error output. If the problem is isolated to a single non-critical report, escalate as medium severity with a proposed rerun plan. If multiple report families are affected, escalate as high severity and request a joint bridge with data engineering.
