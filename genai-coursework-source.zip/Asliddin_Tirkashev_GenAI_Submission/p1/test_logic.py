import math
import numpy as np
import faiss
from p1_retriever import *

def run():
    t={'doc_id':'t','service_name':'X','text':'a'*1200,'sections':[{'section_id':'s1_a','start':0,'end':600},{'section_id':'s2_b','start':600,'end':1200}]}
    c=chunk_fixed(t)
    assert [(x['start'],x['end']) for x in c]==[(0,500),(450,950),(900,1200)]
    assert c[1]['section_ids']==['s1_a','s2_b']
    t['text']='b'*1300;t['sections']=[{'section_id':'s1_a','start':0,'end':300},{'section_id':'s2_b','start':300,'end':1300}]
    c=chunk_by_section(t)
    assert [(x['start'],x['end']) for x in c]==[(0,300),(300,1100),(1020,1300)]
    assert all(len(x['section_ids'])==1 for x in c)
    assert chunk_fixed({'text':'','sections':[],'doc_id':'x','service_name':'X'})==[]
    for params in [(0,0),(20,20),(20,-1)]:
        try:chunk_fixed(t,*params)
        except ValueError:pass
        else:raise AssertionError('Invalid overlap not rejected')
    assert hit_at_k([False,True,False],1)==0 and hit_at_k([False,True,False],3)==1
    assert mrr([False,False,True])==1/3 and mrr([False]*5)==0
    inc={'gold':{'gold_sections':['d#s2','d#s4']}}
    ch=[{'doc_id':'d','section_ids':['s2']},{'doc_id':'x','section_ids':['s4']}]
    assert section_recall(ch,inc)==.5
    assert section_recall(ch+ch,inc)==.5
    assert distractor_at_3([{'doc_id':'x'},{'doc_id':'runbook_payment_reporting'}])==1
    # An exact filtered search must find eligible chunks even after 50 global hits.
    vectors=np.array([[1.,0.]]*55+[[.9,.1],[.8,.2]],dtype='float32');faiss.normalize_L2(vectors)
    index=faiss.IndexFlatIP(2);index.add(vectors)
    chunks=[{'doc_id':str(i),'service_name':'Wrong','section_ids':['s1']} for i in range(55)]
    chunks += [{'doc_id':'correct','service_name':'Right','section_ids':['s1']},{'doc_id':'policy','service_name':'POLICY','section_ids':['s1']}]
    idx={'index':index,'chunks':chunks};q=np.array([[1.,0.]],dtype='float32')
    f=retrieve_vector(q,idx,2,'Right')
    assert [c['doc_id'] for c in f]==['correct','policy']
    assert len(retrieve_vector(q,idx,5,'UNKNOWN'))==5
    assert retrieve_vector(q,idx,0,'Right')==[]
    print('Chunk boundaries, metric edge cases, and exact metadata filtering passed.')
if __name__=='__main__':run()
