"""One post-analysis retrieval fix, kept separate from the six required arms."""
import json
import os
from pathlib import Path
import time

import pandas as pd
from p1_retriever import Retriever, append_jsonl, read_jsonl, hit_at_k, mrr, is_relevant, section_recall, distractor_at_3

HERE = Path(__file__).resolve().parent
RESULTS = Path(os.environ.get('GENAI_P1_RESULTS', HERE / 'results'))
DATA = Path(os.environ.get('GENAI_DATA', HERE.parent / 'data/chaoscorp'))
EXPANSION = 'Find symptoms, safe mitigation and escalation for this incident:\n'


def main():
    cfg = json.loads((RESULTS / 'p1_best_config.json').read_text())
    plan = RESULTS / 'query_expansion_plan.json'
    if not plan.exists():
        plan.write_text(json.dumps({
            'change': 'Prefix every query with the same general triage information needs.',
            'prefix': EXPANSION,
            'expectation': 'I expect escalation coverage to improve, with possible loss of incident-specific first-hit ranking. This cannot repair a wrong service filter.',
            'recorded_before_run': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'status': 'Post-analysis exploratory comparison, not an additional independent test set.'
        }, indent=2))
    elif json.loads(plan.read_text())['prefix'] != EXPANSION:
        raise ValueError('Existing exploratory run uses another query prefix.')
    model = cfg['model']
    retriever = Retriever(DATA, cfg['chunking'], cfg['own_size'], cfg['own_overlap'], model=model, result_dir=RESULTS)
    predictions = {r['incident_key']: r['service_name'] for r in read_jsonl(RESULTS / 'service_predictions.jsonl')}
    path = RESULTS / 'query_expansion_results.jsonl'
    records = read_jsonl(path)
    done = {r['incident_key'] for r in records}
    for inc in json.loads((DATA / 'incidents_test.json').read_text()):
        key = inc['incident_key']
        if key in done:
            continue
        service = predictions[key] if cfg['use_filter'] else None
        started = time.perf_counter()
        chunks = retriever.retrieve(EXPANSION + inc['raw_log'], k=5, service_filter=service)
        latency = 1000 * (time.perf_counter() - started)
        rel = [is_relevant(c, inc) for c in chunks]
        row = {'incident_key': key, 'hit@1': hit_at_k(rel, 1), 'hit@3': hit_at_k(rel, 3),
               'mrr@5': mrr(rel), 'section_recall@5': section_recall(chunks, inc),
               'distractor@3': distractor_at_3(chunks), 'latency_ms': latency,
               'guessed_service': predictions[key], 'retrieved': chunks}
        append_jsonl(path, row); records.append(row)
    metrics = ['hit@1', 'hit@3', 'mrr@5', 'section_recall@5', 'distractor@3', 'latency_ms']
    summary = pd.DataFrame(records)[metrics].mean().to_dict()
    assert len(records) == 25
    (RESULTS / 'query_expansion_summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
