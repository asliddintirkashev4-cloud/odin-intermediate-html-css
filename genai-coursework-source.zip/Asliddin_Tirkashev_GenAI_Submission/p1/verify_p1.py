"""Independently verify stored P1 evidence and the notebook's local replay path."""
from pathlib import Path
import ast
import hashlib
import json
import os
import tempfile
import contextlib
import io

import faiss
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
DATA = HERE.parent / 'data/chaoscorp'
RESULTS = HERE / 'results'

def read_rows(name):
    return [json.loads(s) for s in (RESULTS/name).read_text().splitlines() if s.strip()]

def check_replay_path():
    notebook = json.loads((HERE/'P1_faiss_retrieval.ipynb').read_text())
    source = ''.join(notebook['cells'][13]['source'])
    assignment = next(n for n in ast.parse(source).body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == 'RESULTS' for t in n.targets))
    keys = [key for key in os.environ if key.startswith('GENAI_')] + ['OLLAMA_URL']
    old = {key:os.environ.pop(key) for key in keys if key in os.environ}
    previous = Path.cwd()
    try:
        with tempfile.TemporaryDirectory() as tmp:
            temporary_root = Path(tmp).resolve()
            base = temporary_root/'p1'; (base/'results').mkdir(parents=True)
            data = temporary_root/'data/chaoscorp'; data.mkdir(parents=True)
            (data/'schema_v2.json').write_text('{}')
            os.chdir(base)
            namespace = {}
            with contextlib.redirect_stdout(io.StringIO()):
                exec(''.join(notebook['cells'][5]['source']),namespace)
                exec(''.join(notebook['cells'][9]['source']),namespace)
            assert namespace['CONTENT'] == base and namespace['DATA'] == data
            exec(compile(ast.Module(body=[assignment],type_ignores=[]),'<results assignment>','exec'),namespace)
            assert namespace['RESULTS'] == base/'results', (
                'Local replay misses the packaged p1/results directory', namespace['RESULTS'])
            assert os.environ['GENAI_OLLAMA_URL'] == namespace['OLLAMA_URL']
    finally:
        os.chdir(previous)
        for key in list(os.environ):
            if key.startswith('GENAI_'):os.environ.pop(key)
        os.environ.update(old)

def check_evidence():
    incidents = {r['incident_key']:r for r in json.loads((DATA/'incidents_test.json').read_text())}
    records = read_rows('retrieval_results.jsonl')
    assert len(records) == 150
    assert len({(r['chunking'],r['use_filter'],r['incident_key']) for r in records}) == 150
    service_calls = read_rows('service_calls.jsonl')
    predictions = {r['incident_key']:r for r in read_rows('service_predictions.jsonl')}
    assert len(service_calls) == len(predictions) == 25
    call_by_log = {r['raw_log']:r for r in service_calls}
    for key,incident in incidents.items():
        call = call_by_log[incident['raw_log']]
        assert call['messages'][-1] == {'role':'user','content':incident['raw_log']}
        assert json.loads(call['raw_output'])['service_name'] == predictions[key]['service_name']
    vectors = {}
    chunks = {}
    for name in ['C1','C2','C1_own']:
        chunks[name] = json.loads((RESULTS/f'chunks_{name}.json').read_text())
        index = faiss.read_index(str(RESULTS/f'index_{name}.faiss'))
        vectors[name] = index.reconstruct_n()
        assert index.ntotal == len(chunks[name]) and index.d == 768
        np.testing.assert_allclose(np.linalg.norm(vectors[name],axis=1),1,atol=2e-6)
    recomputed = []
    maximum_score_error = 0.
    distractors = {'runbook_paymentgateway_v1_deprecated','runbook_payment_reporting','guide_platform_k8s_operations'}
    for row in records:
        incident = incidents[row['incident_key']]
        gold = set(incident['gold']['gold_sections'])
        found = row['retrieved']
        covered = [set(c['doc_id']+'#'+s for s in c['section_ids']) for c in found]
        relevant = [bool(s & gold) for s in covered]
        independent = {
            'hit@1':int(any(relevant[:1])), 'hit@3':int(any(relevant[:3])),
            'mrr@5':next((1/(i+1) for i,v in enumerate(relevant[:5]) if v),0),
            'section_recall@5':len(gold.intersection(set().union(*covered[:5])))/len(gold),
            'distractor@3':int(any(c['doc_id'] in distractors for c in found[:3])),
        }
        for key,value in independent.items():
            assert abs(row[key]-value)<1e-12,(row['incident_key'],key,row[key],value)
        key = hashlib.sha256(('nomic-embed-text\0search_query: '+incident['raw_log']).encode()).hexdigest()
        q = np.load(RESULTS/'embedding_cache'/f'{key}.npy',allow_pickle=False)
        scores = vectors[row['chunking']] @ (q/np.linalg.norm(q))
        candidates = [i for i,c in enumerate(chunks[row['chunking']])
                      if not row['use_filter'] or row['guessed_service']=='UNKNOWN'
                      or c['service_name'] in {row['guessed_service'],'POLICY'}]
        ranking = sorted(candidates,key=lambda i:-float(scores[i]))[:5]
        assert [chunks[row['chunking']][i]['chunk_id'] for i in ranking] == [c['chunk_id'] for c in found],row['incident_key']
        error = max(abs(float(scores[i])-c['score']) for i,c in zip(ranking,found))
        maximum_score_error = max(maximum_score_error,error)
        assert error<2e-5,(row['incident_key'],error)
        recomputed.append({'chunking':row['chunking'],'use_filter':row['use_filter'],**independent})
    expected = pd.DataFrame(recomputed).groupby(['chunking','use_filter']).mean()
    stored = pd.read_csv(RESULTS/'p1_summary.csv').set_index(['chunking','use_filter'])
    for key in expected.columns:
        np.testing.assert_allclose(expected[key],stored.loc[expected.index,key],atol=1e-12)
    best = json.loads((RESULTS/'p1_best_config.json').read_text())
    selected = [r for r in records if r['chunking']==best['chunking'] and r['use_filter']==best['use_filter']]
    weakest = sorted(selected,key=lambda r:(r['hit@3'],r['mrr@5'],r['section_recall@5']))[:5]
    assert [r['incident_key'] for r in weakest] == [r['incident_key'] for r in json.loads((RESULTS/'five_weakest_cases.json').read_text())]
    print(f'Independently verified150 scores/rankings and all metrics; maximum cosine delta={maximum_score_error:.3g}.')

if __name__ == '__main__':
    check_evidence()
    check_replay_path()
    print('Local notebook default reuses the packaged results directory.')
