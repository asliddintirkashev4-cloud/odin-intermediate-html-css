"""Exact cosine retrieval for Chaos Corp runbooks and policies."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import time
import urllib.request

import faiss
import numpy as np

DISTRACTORS = {
    "runbook_paymentgateway_v1_deprecated",
    "runbook_payment_reporting",
    "guide_platform_k8s_operations",
}
EMBED_MODEL = "nomic-embed-text"
DEFAULT_MODEL = "qwen3:1.7b-q4_K_M"


def append_jsonl(path, record):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def read_jsonl(path):
    path = Path(path)
    return [json.loads(s) for s in path.read_text().splitlines() if s.strip()] if path.exists() else []


def api_post(route, payload, timeout=900):
    url = os.environ.get("GENAI_OLLAMA_URL", "http://localhost:11434")
    req = urllib.request.Request(url + route, json.dumps(payload).encode(), {"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def load_corpus(data_path):
    data_path = Path(data_path)
    docs = []
    for path in sorted((data_path / "runbooks").glob("*.md")) + sorted((data_path / "policies").glob("*.md")):
        text = path.read_text()
        doc_id = re.search(r"^doc_id: (.+)$", text, re.M).group(1).strip()
        m = re.search(r"^service_name: (.+)$", text, re.M)
        service = m.group(1).strip() if m else "POLICY"
        heads = list(re.finditer(r"^## (s\d+_[a-z_]+) — (.+)$", text, re.M))
        sections = [
            {"section_id": h.group(1), "title": h.group(2), "start": h.start(),
             "end": heads[i + 1].start() if i + 1 < len(heads) else len(text)}
            for i, h in enumerate(heads)
        ]
        if not sections:
            raise ValueError(f"No sections found: {path}")
        docs.append({"doc_id": doc_id, "service_name": service, "text": text, "sections": sections})
    if len(docs) != 16:
        raise ValueError(f"Expected 16 documents, found {len(docs)}")
    return docs


def sections_overlapping(doc, start, end):
    return [s["section_id"] for s in doc["sections"] if s["start"] < end and start < s["end"]]


def _check_window(size, overlap):
    if not isinstance(size, int) or size <= 0 or not isinstance(overlap, int) or not 0 <= overlap < size:
        raise ValueError("size must be positive and overlap must be an integer in [0, size)")


def chunk_fixed(doc, size=500, overlap=50):
    _check_window(size, overlap)
    chunks, text, start = [], doc["text"], 0
    if not text:
        return chunks
    while True:
        end = min(start + size, len(text))
        chunks.append({"chunk_id": f"{doc['doc_id']}#C1-{len(chunks):03d}", "doc_id": doc["doc_id"],
                       "service_name": doc["service_name"], "start": start, "end": end,
                       "text": text[start:end], "section_ids": sections_overlapping(doc, start, end)})
        if end == len(text):
            break
        start = end - overlap
    return chunks


def chunk_by_section(doc, max_len=800, overlap=80):
    _check_window(max_len, overlap)
    chunks, text = [], doc["text"]
    for sec in doc["sections"]:
        start = sec["start"]
        while start < sec["end"]:
            end = min(start + max_len, sec["end"])
            chunks.append({"chunk_id": f"{doc['doc_id']}#C2-{len(chunks):03d}", "doc_id": doc["doc_id"],
                           "service_name": doc["service_name"], "start": start, "end": end,
                           "text": text[start:end], "section_ids": [sec["section_id"]]})
            if end == sec["end"]:
                break
            start = end - overlap
    return chunks


def hit_at_k(rel, k):
    return int(any(rel[:k]))


def mrr(rel, k=5):
    return next((1.0 / (i + 1) for i, relevant in enumerate(rel[:k]) if relevant), 0.0)


def gold_set(inc):
    return {tuple(s.split("#")) for s in inc["gold"]["gold_sections"]}


def is_relevant(chunk, inc):
    return any((chunk["doc_id"], sec) in gold_set(inc) for sec in chunk["section_ids"])


def section_recall(chunks, inc, k=5):
    gold = gold_set(inc)
    covered = {(chunk["doc_id"], sec) for chunk in chunks[:k] for sec in chunk["section_ids"]}
    return len(gold & covered) / len(gold) if gold else 1.0


def distractor_at_3(chunks):
    return int(any(c["doc_id"] in DISTRACTORS for c in chunks[:3]))


class Embedder:
    """Persistent document cache; query timings include actual uncached API embedding."""
    def __init__(self, cache_dir, model=EMBED_MODEL):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.model = model

    def embed(self, texts, kind, cache=True):
        if kind not in {"document", "query"}:
            raise ValueError("kind must be document or query")
        prefix = "search_document: " if kind == "document" else "search_query: "
        keys = [hashlib.sha256((self.model + "\0" + prefix + text).encode()).hexdigest() for text in texts]
        vectors = [None] * len(texts)
        missing = []
        for i, key in enumerate(keys):
            file = self.cache_dir / (key + ".npy")
            if cache and file.exists():
                vectors[i] = np.load(file, allow_pickle=False)
            else:
                missing.append(i)
        for start in range(0, len(missing), 32):
            batch = missing[start:start + 32]
            resp = api_post("/api/embed", {"model": self.model, "input": [prefix + texts[i] for i in batch],
                                            "options": {"num_gpu": int(os.environ.get("GENAI_NUM_GPU", "99" if os.environ.get("GENAI_TRACK", "CPU").upper() == "GPU" else "0"))}}, timeout=900)
            if len(resp["embeddings"]) != len(batch):
                raise ValueError("Embedding API returned wrong vector count")
            for i, vector in zip(batch, resp["embeddings"]):
                v = np.asarray(vector, dtype="float32")
                norm = np.linalg.norm(v)
                if not np.isfinite(norm) or norm <= 0:
                    raise ValueError("Invalid embedding vector")
                vectors[i] = v / norm
                if cache:
                    np.save(self.cache_dir / (keys[i] + ".npy"), vectors[i], allow_pickle=False)
        result = np.asarray(vectors, dtype="float32")
        faiss.normalize_L2(result)
        return result


def build_index(chunks, embedder):
    vecs = embedder.embed([c["text"] for c in chunks], "document")
    index = faiss.IndexFlatIP(vecs.shape[1])
    index.add(vecs)
    return {"index": index, "chunks": chunks}


def retrieve_vector(q, idx, k=5, service_filter=None):
    if k <= 0:
        return []
    # Search all candidates, then retain the permitted metadata subset. This is
    # exact filtered top-k; a fixed shortlist could discard permitted candidates.
    scores, ids = idx["index"].search(q, idx["index"].ntotal)
    results = []
    filtering = bool(service_filter) and service_filter != "UNKNOWN"
    for score, i in zip(scores[0], ids[0]):
        if i < 0:
            continue
        ch = idx["chunks"][int(i)]
        if filtering and ch["service_name"] not in {service_filter, "POLICY"}:
            continue
        results.append({**ch, "score": float(score)})
        if len(results) == k:
            break
    return results


def retrieve(query_text, idx, embedder, k=5, service_filter=None):
    q = embedder.embed([query_text], "query", cache=False)
    return retrieve_vector(q, idx, k=k, service_filter=service_filter)


def extract_service(raw_log, services, model=DEFAULT_MODEL, log_path=None):
    names = [s["service_name"] for s in services]
    schema = {"type": "object", "properties": {"service_name": {"type": "string", "enum": names + ["UNKNOWN"]}},
              "required": ["service_name"], "additionalProperties": False}
    aliases = "\n".join(f"- {s['service_name']} (also called: {', '.join(s['aliases'])})" for s in services)
    messages = [
        {"role": "system", "content": "Name the affected Chaos Corp service. Map aliases to the canonical name. "
         "If two services are mentioned, choose the one where the fault is.\n" + aliases},
        {"role": "user", "content": raw_log},
    ]
    body = {"model": model, "messages": messages, "stream": False, "format": schema,
            "options": {"temperature": 0, "seed": 42,
                        "num_ctx": 4096 if os.environ.get("GENAI_TRACK", "CPU").upper() == "GPU" else 2048,
                        "num_predict": 256 if os.environ.get("GENAI_TRACK", "CPU").upper() == "GPU" else 200,
                        "num_gpu": int(os.environ.get("GENAI_NUM_GPU", "99" if os.environ.get("GENAI_TRACK", "CPU").upper() == "GPU" else "0"))}}
    if model.startswith("qwen3"):
        body["think"] = False
    t0 = time.perf_counter()
    resp = api_post("/api/chat", body)
    latency = time.perf_counter() - t0
    raw = resp["message"]["content"]
    try:
        service = json.loads(raw)["service_name"]
        if service not in names + ["UNKNOWN"]:
            raise ValueError("unknown canonical service")
        error = None
    except (ValueError, KeyError, TypeError) as e:
        service, error = "UNKNOWN", str(e)
    if log_path:
        append_jsonl(log_path, {"query_sha256": hashlib.sha256(raw_log.encode()).hexdigest(), "model": model,
                                "raw_log": raw_log, "messages": messages, "raw_output": raw,
                                "service_name": service, "latency_s": latency, "error": error,
                                "eval_count": resp.get("eval_count"), "eval_duration": resp.get("eval_duration")})
    return service


class Retriever:
    def __init__(self, data_path, chunking="C2", own_size=350, own_overlap=60,
                 model=None, result_dir=None):
        self.data_path = Path(data_path)
        self.result_dir = Path(result_dir or Path(__file__).parent / "results")
        self.result_dir.mkdir(parents=True, exist_ok=True)
        self.model = model or os.environ.get("GENAI_MODEL", DEFAULT_MODEL)
        self.docs = load_corpus(self.data_path)
        self.services = json.loads((self.data_path / "services.json").read_text())["services"]
        self.embedder = Embedder(self.result_dir / "embedding_cache")
        if chunking == "C2":
            chunks = [c for d in self.docs for c in chunk_by_section(d)]
        elif chunking in {"C1", "C1_own"}:
            size, overlap = (500, 50) if chunking == "C1" else (own_size, own_overlap)
            chunks = [c for d in self.docs for c in chunk_fixed(d, size, overlap)]
        else:
            raise ValueError("Unknown chunking")
        self.idx = build_index(chunks, self.embedder)
        self.service_cache = {}

    def retrieve(self, query, k=5, service_filter=None):
        return retrieve(query, self.idx, self.embedder, k, service_filter)

    def extract_service(self, raw_log):
        if raw_log not in self.service_cache:
            self.service_cache[raw_log] = extract_service(raw_log, self.services, self.model,
                                                        self.result_dir / "service_calls.jsonl")
        return self.service_cache[raw_log]

    def retrieve_for_incident(self, raw_log, k=3, use_filter=True):
        service = self.extract_service(raw_log) if use_filter else None
        return self.retrieve(raw_log, k=k, service_filter=service)
