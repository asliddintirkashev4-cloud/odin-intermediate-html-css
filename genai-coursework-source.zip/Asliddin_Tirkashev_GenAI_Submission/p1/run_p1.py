"""Run the six retrieval configurations and preserve their complete evidence."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import time

import pandas as pd

from p1_retriever import (
    DEFAULT_MODEL, DISTRACTORS, EMBED_MODEL, Embedder, append_jsonl, build_index,
    chunk_by_section, chunk_fixed, distractor_at_3, extract_service, gold_set,
    hit_at_k, is_relevant, load_corpus, mrr, read_jsonl, retrieve, section_recall,
)

HERE = Path(__file__).resolve().parent
OWN_SIZE, OWN_OVERLAP = 350, 60
EXPECTATION = (
    "I expect 350-character chunks with 60-character overlap to improve first-hit precision "
    "over 500/50 by mixing fewer sections, while possibly reducing section recall because "
    "each of the five retrieved chunks covers less text."
)


def config_identity(data_path, model):
    track = os.environ.get("GENAI_TRACK", "CPU").upper()
    files = sorted((Path(data_path) / "runbooks").glob("*.md")) + sorted((Path(data_path) / "policies").glob("*.md"))
    files += [Path(data_path) / name for name in ["incidents_test.json", "services.json"]]
    digest = hashlib.sha256(b"".join(p.name.encode() + p.read_bytes() for p in files)).hexdigest()
    return {"model": model, "embedding_model": EMBED_MODEL, "data_sha256": digest,
            "own_size": OWN_SIZE, "own_overlap": OWN_OVERLAP,
            "track": track, "num_ctx": 4096 if track == "GPU" else 2048,
            "num_predict": 256 if track == "GPU" else 200, "seed": 42, "temperature": 0,
            "num_gpu": int(os.environ.get("GENAI_NUM_GPU", "99" if track == "GPU" else "0"))}


def run(data_path, result_dir, model=DEFAULT_MODEL):
    data_path, result_dir = Path(data_path), Path(result_dir)
    result_dir.mkdir(parents=True, exist_ok=True)
    identity = config_identity(data_path, model)
    identity_path = result_dir / "experiment_identity.json"
    if identity_path.exists() and json.loads(identity_path.read_text()) != identity:
        raise ValueError("Existing results use a different configuration; choose a fresh result directory")
    identity_path.write_text(json.dumps(identity, indent=2))
    prereg = result_dir / "preregistered_experiment.json"
    if not prereg.exists():
        prereg.write_text(json.dumps({"size": OWN_SIZE, "overlap": OWN_OVERLAP, "expectation": EXPECTATION,
                                     "recorded_before_run": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, indent=2))
    docs = load_corpus(data_path)
    incidents = json.loads((data_path / "incidents_test.json").read_text())
    services = json.loads((data_path / "services.json").read_text())["services"]
    chunks = {
        "C1": [c for d in docs for c in chunk_fixed(d)],
        "C2": [c for d in docs for c in chunk_by_section(d)],
        "C1_own": [c for d in docs for c in chunk_fixed(d, OWN_SIZE, OWN_OVERLAP)],
    }
    stats = pd.DataFrame([
        {"strategy": name, "chunks": len(chs), "mean_len": sum(len(c["text"]) for c in chs) / len(chs),
         "min_len": min(len(c["text"]) for c in chs), "max_len": max(len(c["text"]) for c in chs),
         "chunks_spanning_multiple_sections": sum(len(c["section_ids"]) > 1 for c in chs)}
        for name, chs in chunks.items()
    ])
    stats.to_csv(result_dir / "chunk_statistics.csv", index=False)
    embedder = Embedder(result_dir / "embedding_cache")
    indexes = {}
    for name, chs in chunks.items():
        print(f"Indexing {name}: {len(chs)} chunks", flush=True)
        indexes[name] = build_index(chs, embedder)
    predictions_path = result_dir / "service_predictions.jsonl"
    predictions = {r["incident_key"]: r for r in read_jsonl(predictions_path)}
    for inc in incidents:
        key = inc["incident_key"]
        if key in predictions:
            continue
        t0 = time.perf_counter()
        service = extract_service(inc["raw_log"], services, model, result_dir / "service_calls.jsonl")
        row = {"incident_key": key, "service_name": service, "latency_s": time.perf_counter() - t0}
        append_jsonl(predictions_path, row)
        predictions[key] = row
        print(f"Service {len(predictions)}/{len(incidents)} {key}: {service}", flush=True)
    all_path = result_dir / "retrieval_results.jsonl"
    records = read_jsonl(all_path)
    done = {(r["chunking"], r["use_filter"], r["incident_key"]) for r in records}
    for name in chunks:
        for use_filter in [False, True]:
            for inc in incidents:
                key = inc["incident_key"]
                if (name, use_filter, key) in done:
                    continue
                service = predictions[key]["service_name"] if use_filter else None
                t0 = time.perf_counter()
                found = retrieve(inc["raw_log"], indexes[name], embedder, k=5, service_filter=service)
                latency_ms = 1000 * (time.perf_counter() - t0)
                relevance = [is_relevant(c, inc) for c in found]
                row = {"chunking": name, "use_filter": use_filter, "incident_key": key,
                       "guessed_service": predictions[key]["service_name"], "hit@1": hit_at_k(relevance, 1),
                       "hit@3": hit_at_k(relevance, 3), "mrr@5": mrr(relevance),
                       "section_recall@5": section_recall(found, inc), "distractor@3": distractor_at_3(found),
                       "latency_ms": latency_ms,
                       "service_extraction_ms": 1000 * predictions[key]["latency_s"] if use_filter else 0,
                       "retrieved_characters@5": sum(len(c["text"]) for c in found),
                       "retrieved": found}
                append_jsonl(all_path, row)
                records.append(row)
                done.add((name, use_filter, key))
            print(f"Evaluated {name}, filter={use_filter}", flush=True)
    frame = pd.DataFrame(records)
    metrics = ["hit@1", "hit@3", "mrr@5", "section_recall@5", "distractor@3", "latency_ms", "service_extraction_ms", "retrieved_characters@5"]
    summary = frame.groupby(["chunking", "use_filter"], sort=False)[metrics].mean().reset_index()
    summary.to_csv(result_dir / "p1_summary.csv", index=False)
    best = summary.sort_values("mrr@5", ascending=False, kind="stable").iloc[0]
    best_config = {"chunking": str(best["chunking"]), "use_filter": bool(best["use_filter"]),
                   "own_size": OWN_SIZE, "own_overlap": OWN_OVERLAP, "model": model,
                   "embedding_model": EMBED_MODEL, "track": identity["track"],
                   "metrics": {key: float(best[key]) for key in metrics},
                   "selection_rule": "highest MRR@5; stable original config order breaks ties"}
    (result_dir / "p1_best_config.json").write_text(json.dumps(best_config, indent=2))
    chosen = frame[(frame.chunking == best_config["chunking"]) & (frame.use_filter == best_config["use_filter"])]
    weakest = chosen.sort_values(["hit@3", "mrr@5", "section_recall@5"], kind="stable").head(5)
    by_key = {inc["incident_key"]: inc for inc in incidents}
    failure_records = []
    for row in weakest.to_dict("records"):
        inc = by_key[row["incident_key"]]
        covered = {(c["doc_id"], section) for c in row["retrieved"] for section in c["section_ids"]}
        missing = sorted("#".join(g) for g in gold_set(inc) - covered)
        if best_config["use_filter"] and row["guessed_service"] not in {"UNKNOWN", inc["gold"]["service_name"]}:
            diagnosis = "wrong service guess (filter)"
            explanation = f"The extractor selected {row['guessed_service']}; filtering removed {inc['gold']['service_name']}'s runbook."
        elif row["distractor@3"]:
            diagnosis = "distractor wins"
            explanation = "A look-alike document occupies a top-three result, reducing the useful result budget."
        elif missing:
            diagnosis = "escalation section not retrieved" if any("s6_escalation" in s for s in missing) else "some gold sections missing"
            explanation = "The five highest similarity scores do not cover " + ", ".join(missing) + "."
        elif row["hit@1"] == 0:
            diagnosis = "useful passage ranked below an irrelevant passage"
            explanation = "Similarity places an overview, cause or triage passage before a labelled symptoms/mitigation passage."
        else:
            diagnosis = "success"
            explanation = "A relevant passage ranks first and all labelled sections appear within five results."
        failure_records.append({"incident_key": row["incident_key"], "raw_log": inc["raw_log"],
                                "gold_sections": inc["gold"]["gold_sections"], "hard_case_tags": inc["gold"]["hard_case_tags"],
                                "guessed_service": row["guessed_service"], "top3": row["retrieved"][:3],
                                "hit@1": row["hit@1"], "hit@3": row["hit@3"], "mrr@5": row["mrr@5"],
                                "section_recall@5": row["section_recall@5"], "diagnosis": diagnosis, "explanation": explanation})
    (result_dir / "five_weakest_cases.json").write_text(json.dumps(failure_records, ensure_ascii=False, indent=2))
    packages = {}
    for name in ["numpy", "faiss-cpu", "pandas", "requests", "pydantic", "langchain", "langchain-ollama"]:
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = "not installed"
    runtime = {"python": platform.python_version(), "platform": platform.platform(), "packages": packages,
               "model": model, "embedding_model": EMBED_MODEL, "track": identity["track"], "num_gpu": identity["num_gpu"],
               "latency_scope": "query embedding plus exact FAISS search; service-extractor latency is separately reported",
               "execution_location": os.environ.get("GENAI_RUNTIME", "Google Colab" if "COLAB_RELEASE_TAG" in os.environ else "local runtime"),
               "completed_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    (result_dir / "runtime.json").write_text(json.dumps(runtime, indent=2))
    print(summary.to_string(index=False), flush=True)
    print("Best:", best_config, flush=True)
    return best_config


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=HERE.parent / "data/chaoscorp")
    parser.add_argument("--results", type=Path, default=HERE / "results")
    parser.add_argument("--model", default=os.environ.get("GENAI_MODEL", DEFAULT_MODEL))
    args = parser.parse_args()
    run(args.data, args.results, args.model)
