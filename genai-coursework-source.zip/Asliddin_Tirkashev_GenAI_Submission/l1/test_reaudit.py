"""Regression checks for profiling cache identity and original provenance."""
import json
import tempfile
import unittest
import sys
from pathlib import Path
from unittest.mock import patch

import l1_experiment as lab


class ProfileCacheTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.data = self.root / 'data'
        (self.data / 'policies').mkdir(parents=True)
        (self.data / 'incidents_original10.json').write_text('[{"incident_key":"T","raw_log":"first"}]')
        (self.data / 'policies/policy_severity.md').write_text('Severity policy')
        self.patches = [patch.object(lab, 'RESULTS', self.root / 'results'),
                        patch.object(lab, 'DATA', self.data),
                        patch.object(lab, 'unload_all'), patch.object(lab, 'unload'),
                        patch.object(lab, 'nvidia_memory_gb', return_value=None),
                        patch.object(lab, 'memory', return_value={'size_gb': 1., 'vram_gb': 0., 'processor': '100% CPU'}),
                        patch.object(lab, 'chat', return_value=self.response()),
                        patch.object(lab, 'run', return_value=self.response()),
                        patch.object(lab, 'severity_accuracy', return_value=[{'correct': True}])]
        for item in self.patches:
            item.start()

    def tearDown(self):
        for item in reversed(self.patches): item.stop()
        self.temp.cleanup()

    @staticmethod
    def response():
        return {'load_duration': 1, 'eval_count': 10, 'eval_duration': 1_000_000_000,
                'prompt_eval_count': 20, 'prompt_eval_duration': 1_000_000_000}

    def test_changed_standard_prompt_cannot_reuse_profile(self):
        lab.profile_model(lab.EXP_A[0], 'A')
        with patch.object(lab, 'PROMPT', lab.PROMPT + ' changed'):
            with self.assertRaisesRegex(RuntimeError, 'configuration|identity'):
                lab.profile_model(lab.EXP_A[0], 'A')

    def test_changed_incident_log_cannot_reuse_profile(self):
        lab.profile_model(lab.EXP_A[0], 'A')
        (self.data / 'incidents_original10.json').write_text('[{"incident_key":"T","raw_log":"different"}]')
        with self.assertRaisesRegex(RuntimeError, 'configuration|identity'):
            lab.profile_model(lab.EXP_A[0], 'A')

    def test_changed_options_cannot_reuse_parallel_test(self):
        lab.parallel_test(lab.EXP_B[-1], 2)
        with patch.object(lab, 'OPTIONS', {**lab.OPTIONS, 'num_ctx': 1024}):
            with self.assertRaisesRegex(RuntimeError, 'configuration|identity'):
                lab.parallel_test(lab.EXP_B[-1], 2)

    def test_cache_replay_does_not_overwrite_measurement_runtime(self):
        lab.RESULTS.mkdir(parents=True)
        runtime=lab.RESULTS/'runtime.json'
        original='{"runtime":"original measured host","created_utc":"original"}'
        runtime.write_text(original)
        (lab.RESULTS/'langchain_response.json').write_text('{}')
        choice={'model':lab.EXP_B[-1]}
        with patch.object(sys,'argv',['l1_experiment.py']), \
             patch.object(lab,'api',return_value={'version':'new replay server'}), \
             patch.object(lab,'profile_model',return_value=choice), \
             patch.object(lab,'choose_model',return_value=choice), \
             patch.object(lab,'parallel_test',return_value={}), \
             patch.object(lab,'save_summary',return_value=choice):
            lab.main()
        self.assertEqual(runtime.read_text(),original)


if __name__ == '__main__': unittest.main()
