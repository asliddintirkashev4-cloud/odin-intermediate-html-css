"""Lab 1 GPU/CPU-track profiling. Real Ollama responses, saved incrementally."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import platform
import shutil
import statistics
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import requests
import pandas as pd

HERE=Path(__file__).resolve().parent if '__file__' in globals() else Path.cwd()
DATA=Path(os.environ.get('GENAI_DATA',str(HERE.parent/'data/chaoscorp')))
RESULTS=Path(os.environ.get('GENAI_L1_RESULTS',str(HERE/'results')))
OLLAMA_URL=os.environ.get('OLLAMA_URL','http://localhost:11435').rstrip('/')
TRACK=os.environ.get('GENAI_TRACK','CPU').upper()
if TRACK not in ('CPU','GPU'):raise ValueError('GENAI_TRACK must be CPU or GPU')
IN_COLAB=bool(os.environ.get('COLAB_RELEASE_TAG') or os.environ.get('COLAB_GPU') or os.environ.get('GENAI_IN_COLAB'))
RUNTIME=os.environ.get('GENAI_RUNTIME',('Google Colab ' if IN_COLAB else 'local ')+TRACK)
if TRACK=='GPU':
    EXP_A=['llama3.2:3b-instruct-q4_K_M','llama3.2:3b-instruct-q8_0','llama3.2:3b-instruct-fp16']
    EXP_B=['qwen3:1.7b-q4_K_M','qwen3:4b-q4_K_M','qwen3:8b-q4_K_M']
else:
    EXP_A=['llama3.2:1b-instruct-q4_K_M','llama3.2:1b-instruct-q8_0','llama3.2:1b-instruct-fp16']
    EXP_B=['qwen3:0.6b-q4_K_M','qwen3:1.7b-q4_K_M']
N_RUNS=5 if TRACK=='GPU' else 3
N_PARALLEL=4 if TRACK=='GPU' else 2
OPTIONS={'temperature':0,'seed':42,'num_ctx':4096 if TRACK=='GPU' else 2048,
         'num_predict':256 if TRACK=='GPU' else 200,'num_gpu':99 if TRACK=='GPU' else 0}
PROMPT='Explain to a new on-call engineer, in at most 120 words, why a read replica can show higher latency than the primary database.'

def read_jsonl(path):
    p=Path(path)
    return [json.loads(line) for line in p.read_text().splitlines() if line.strip()] if p.exists() else []

def append_jsonl(path,row):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('a',encoding='utf-8') as f:
        f.write(json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())

def decode_tps(resp):
    return resp['eval_count']/(resp['eval_duration']/1e9) if resp.get('eval_duration',0)>0 else 0.0

def prompt_tps(resp):
    return resp['prompt_eval_count']/(resp['prompt_eval_duration']/1e9) if resp.get('prompt_eval_duration',0)>0 else 0.0

def api(path,body=None,timeout=900):
    r=requests.get(OLLAMA_URL+path,timeout=timeout) if body is None else requests.post(OLLAMA_URL+path,json=body,timeout=timeout)
    r.raise_for_status();return r.json()

def loaded_models():
    return api('/api/ps',timeout=10).get('models',[])

def unload(model):
    return api('/api/generate',{'model':model,'keep_alive':0},timeout=90)

def unload_all():
    for row in loaded_models():unload(row['name'])
    for _ in range(60):
        if not loaded_models():return
        time.sleep(.2)
    raise RuntimeError('A model remained loaded before the next benchmark.')

def pull(model):
    return api('/api/pull',{'model':model,'stream':False},timeout=3600)

def chat(model,messages,phase,options=None,case=None):
    body={'model':model,'messages':messages,'stream':False,'keep_alive':'10m','options':{**OPTIONS,**(options or {})}}
    if model.startswith('qwen3'):body['think']=False
    started=time.perf_counter();response=api('/api/chat',body)
    elapsed=time.perf_counter()-started
    append_jsonl(RESULTS/'responses.jsonl',{'timestamp_utc':datetime.now(timezone.utc).isoformat(),'model':model,'phase':phase,'case':case,'options':body['options'],'wall_s':elapsed,'response':response})
    return response

def run(model,prompt,phase='timed',case=None):
    """Standard prompt call with fixed settings; returns Ollama's full response."""
    return chat(model,[{'role':'user','content':prompt}],phase,case=case)

def memory(model):
    row=next((r for r in loaded_models() if r['name']==model or r.get('model')==model),None)
    if row is None:raise RuntimeError(f'Loaded model missing from /api/ps: {model}')
    size=row.get('size',0);vram=row.get('size_vram',0)
    if TRACK=='CPU' and vram:raise RuntimeError(f'Declared CPU run used GPU memory ({vram} bytes).')
    share=vram/size if size else 0
    processor='100% CPU' if share==0 else ('100% GPU' if share>=.99 else f'{100*share:.1f}% GPU / {100*(1-share):.1f}% CPU')
    return {'size_gb':size/1e9,'vram_gb':vram/1e9,'gpu_share':vram/size if size else 0,
            'processor':processor,'gpu_comparable':TRACK!='GPU' or share>=.99,'ollama_ps':row}

def nvidia_memory_gb():
    if TRACK!='GPU' or not shutil.which('nvidia-smi'):return None
    result=subprocess.run(['nvidia-smi','--query-gpu=memory.used','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True)
    return float(result.stdout.splitlines()[0].strip())*1024**2/1e9

def mean_sd(values):
    return statistics.mean(values),statistics.pstdev(values)

def experiment_identity():
    """Inputs which must match before reusing measurements."""
    return {'version':1,'track':TRACK,'options':OPTIONS,'standard_prompt':PROMPT,
            'timed_runs':N_RUNS,'parallel_requests':[1,N_PARALLEL],
            'experiment_a':EXP_A,'experiment_b':EXP_B,
            'incidents_sha256':hashlib.sha256((DATA/'incidents_original10.json').read_bytes()).hexdigest(),
            'severity_policy_sha256':hashlib.sha256((DATA/'policies/policy_severity.md').read_bytes()).hexdigest()}

def ensure_cache_identity():
    identity=experiment_identity()
    path=RESULTS/'experiment_manifest.json'
    if path.exists():
        if json.loads(path.read_text())['identity']!=identity:
            raise RuntimeError('Cached experiment configuration/identity differs; use a new results folder.')
    else:
        if any(read_jsonl(RESULTS/name) for name in ['profiles.jsonl','parallel.jsonl','responses.jsonl']):
            raise RuntimeError('Legacy cached measurements have no identity manifest; audit them or use a new results folder.')
        RESULTS.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps({'identity':identity,'established_utc':datetime.now(timezone.utc).isoformat(),
                                    'established_by':'before model calls'},indent=2))
    return identity

def severity_accuracy(model):
    incidents=json.loads((DATA/'incidents_original10.json').read_text())
    guide=(DATA/'policies/policy_severity.md').read_text()
    predictions=[]
    for inc in incidents:
        r=chat(model,[{'role':'system','content':'You classify incident severity using this guide:\n'+guide},
                      {'role':'user','content':inc['raw_log']+'\n\nAnswer with exactly one word: High, Medium or Low.'}],
               'severity',options={'num_predict':10},case=inc['incident_key'])
        answer=r['message']['content'].strip()
        predicted=next((s for s in ('High','Medium','Low') if answer.casefold()==s.casefold()),None)
        predictions.append({'incident_key':inc['incident_key'],'raw':answer,'predicted':predicted,'gold':inc['gold']['severity'],'correct':predicted==inc['gold']['severity']})
    return predictions

def profile_model(model,experiment):
    ensure_cache_identity()
    path=RESULTS/'profiles.jsonl'
    old=next((r for r in read_jsonl(path) if r['model']==model and r['experiment']==experiment),None)
    if old is not None:
        if old.get('options')!=OPTIONS:raise RuntimeError('Cache options differ; use a new result folder.')
        return old
    unload_all()
    before=nvidia_memory_gb()
    load=chat(model,[{'role':'user','content':'Hi'}],'load',{'num_predict':1})
    after=nvidia_memory_gb()
    mem=memory(model)
    run(model,PROMPT,'warmup')
    runs=[run(model,PROMPT,'timed',case=i+1) for i in range(N_RUNS)]
    predictions=severity_accuracy(model)
    row={'model':model,'experiment':experiment,'track':TRACK,'options':OPTIONS,'runs':N_RUNS,
         **mem,'load_s':load['load_duration']/1e9,'severity_correct_of_10':sum(p['correct'] for p in predictions),
         'nvidia_memory_before_gb':before,'nvidia_memory_after_gb':after,
         'nvidia_vram_delta_gb':after-before if before is not None and after is not None else None,
         'severity_predictions':predictions,'raw_timed_responses':runs}
    for metric,values in {'decode_tps':[decode_tps(r) for r in runs],
                          'prompt_tps':[prompt_tps(r) for r in runs],
                          'warm_ttft_s':[r['prompt_eval_duration']/1e9 for r in runs]}.items():
        row[metric+'_mean'],row[metric+'_sd']=mean_sd(values)
    append_jsonl(path,row)
    unload(model)
    print(model,'severity',row['severity_correct_of_10'],'/10; decode',round(row['decode_tps_mean'],2),flush=True)
    return row

def choose_model(rows):
    candidates=[r for r in rows if r['experiment']=='B' and r.get('gpu_comparable',True)]
    if not candidates:raise RuntimeError('No comparable Qwen model measurements are available.')
    # Accuracy first, then measured speed and smaller memory on a tie.
    return max(candidates,key=lambda r:(r['severity_correct_of_10'],r['decode_tps_mean'],-r['size_gb']))

def parallel_test(model,n):
    ensure_cache_identity()
    old=next((r for r in read_jsonl(RESULTS/'parallel.jsonl') if r['model']==model and r['parallel_requests']==n),None)
    if old is not None:return old
    chat(model,[{'role':'user','content':'Hi'}],'parallel_load',{'num_predict':1})
    memory(model)
    started=time.perf_counter()
    with ThreadPoolExecutor(max_workers=n) as pool:
        responses=list(pool.map(lambda i:chat(model,[{'role':'user','content':PROMPT}],f'parallel_{n}',case=i+1),range(n)))
    wall=time.perf_counter()-started
    speeds=[decode_tps(r) for r in responses]
    row={'model':model,'parallel_requests':n,'per_request_tps':speeds,'per_request_tps_mean':statistics.mean(speeds),
         'aggregate_tps':sum(r['eval_count'] for r in responses)/wall,'wall_s':wall,
         'tokens_total':sum(r['eval_count'] for r in responses),'memory':memory(model),'nvidia_memory_gb':nvidia_memory_gb(),'responses':responses}
    append_jsonl(RESULTS/'parallel.jsonl',row)
    return row

def save_summary():
    rows=read_jsonl(RESULTS/'profiles.jsonl')
    flat=[{k:v for k,v in r.items() if k not in ('options','severity_predictions','raw_timed_responses','ollama_ps')} for r in rows]
    pd.DataFrame(flat).to_csv(RESULTS/'profiles.csv',index=False)
    if len(rows)!=len(EXP_A+EXP_B):raise RuntimeError('All model measurements for this track are needed.')
    choice=choose_model(rows)
    parallel=[r for r in read_jsonl(RESULTS/'parallel.jsonl') if r['model']==choice['model']]
    if len(parallel)<2:raise RuntimeError('Both parallel tests are needed.')
    a4=next(r for r in rows if r['model']==EXP_A[0]);a16=next(r for r in rows if r['model']==EXP_A[2])
    ratio=a16['size_gb']/a4['size_gb']
    faster=a4['decode_tps_mean']/a16['decode_tps_mean']
    small=next(r for r in rows if r['model']==EXP_B[0]);large=next(r for r in rows if r['model']==EXP_B[-1])
    pair=next(r for r in parallel if r['parallel_requests']==N_PARALLEL)
    answer_tokens=200
    capacity=pair['aggregate_tps']*20/answer_tokens
    observed_mean_tokens=pair['tokens_total']/pair['parallel_requests']
    answers=[
      f"I measured {a4['size_gb']:.2f} GB for q4_K_M and {a16['size_gb']:.2f} GB for fp16, a {ratio:.2f}-fold memory ratio. Their decode speeds were {a4['decode_tps_mean']:.2f} and {a16['decode_tps_mean']:.2f} tokens/s, respectively ({faster:.2f}x). Severity accuracy was {a4['severity_correct_of_10']}/10 versus {a16['severity_correct_of_10']}/10. I evaluate this trade-off for these logs rather than assuming lower precision always preserves quality.",
      f"In the Qwen3 size comparison, {small['model']} scored {small['severity_correct_of_10']}/10 at {small['decode_tps_mean']:.2f} tokens/s, while {large['model']} scored {large['severity_correct_of_10']}/10 at {large['decode_tps_mean']:.2f} tokens/s. I choose {choice['model']} by highest observed accuracy, then speed and memory efficiency on a tie. The ten-incident sample limits the strength of this comparison.",
      f"The measured {pair['parallel_requests']}-request batch produced {pair['tokens_total']} tokens total, averaging {observed_mean_tokens:.1f} tokens per reply, in {pair['wall_s']:.2f} seconds. Aggregate throughput was {pair['aggregate_tps']:.2f} tokens/s. For a hypothetical 200-token reply, a throughput-only projection gives {pair['aggregate_tps']:.2f} x 20 / 200 = {capacity:.1f} users sending one request every 20 seconds, before safety headroom. The observed reply lengths do not verify a five-second target for 200-token replies. I would test that response length and a realistic arrival pattern before claiming this capacity.",
      f"I select {choice['model']} for later work: it scored {choice['severity_correct_of_10']}/10, decoded at {choice['decode_tps_mean']:.2f} tokens/s and occupied {choice['size_gb']:.2f} GB according to Ollama, including {choice['vram_gb']:.2f} GB of model GPU memory. This is a measured {RUNTIME} result. I keep the model tag and settings fixed in the next tasks."
    ]
    card={'model':choice['model'],'track':TRACK,'runtime':RUNTIME,'decode_tps':choice['decode_tps_mean'],
          'size_gb':choice['size_gb'],'vram_gb':choice['vram_gb'],'severity_correct_of_10':choice['severity_correct_of_10'],
          'reason_for_choice':f"I selected highest measured severity accuracy among Qwen size candidates, breaking ties by measured speed and memory efficiency; accuracy {choice['severity_correct_of_10']}/10, speed {choice['decode_tps_mean']:.2f} tok/s, memory {choice['size_gb']:.2f} GB."}
    (RESULTS/'analysis_answers.json').write_text(json.dumps(answers,indent=2))
    (RESULTS/'model_card.json').write_text(json.dumps(card,indent=2))
    return card

def langchain_call(model):
    from langchain_ollama import ChatOllama
    llm=ChatOllama(model=model,base_url=OLLAMA_URL,temperature=0,seed=42,num_ctx=OPTIONS['num_ctx'],num_predict=OPTIONS['num_predict'],num_gpu=OPTIONS['num_gpu'],
                   **({'reasoning':False} if model.startswith('qwen3') else {}))
    started=time.perf_counter();response=llm.invoke(PROMPT)
    result={'model':model,'wall_s':time.perf_counter()-started,'content':response.content,
            'response_metadata':response.response_metadata,'usage_metadata':response.usage_metadata}
    (RESULTS/'langchain_response.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    return result

def main():
    global OLLAMA_URL
    parser=argparse.ArgumentParser();parser.add_argument('--url');parser.add_argument('--pull',action='store_true');parser.add_argument('--profile-only',action='store_true')
    args=parser.parse_args()
    if args.url:OLLAMA_URL=args.url.rstrip('/')
    RESULTS.mkdir(parents=True,exist_ok=True)
    ensure_cache_identity()
    env={'track':TRACK,'runtime':RUNTIME,'platform':platform.platform(),'ollama':api('/api/version'),
         'url':OLLAMA_URL,'options':OPTIONS,'parallel_server_setting':f'OLLAMA_NUM_PARALLEL={N_PARALLEL}; dedicated course server',
         'created_utc':datetime.now(timezone.utc).isoformat()}
    if TRACK=='GPU' and shutil.which('nvidia-smi'):
        env['nvidia_device']=subprocess.run(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],capture_output=True,text=True,check=True).stdout.strip()
    runtime_path=RESULTS/'runtime.json'
    if not runtime_path.exists():
        runtime_path.write_text(json.dumps(env,indent=2))
    rows=[]
    for experiment,models in [('A',EXP_A),('B',EXP_B)]:
        for model in models:
            if args.pull:
                print('Preparing model:', model, flush=True)
                pull(model)
            rows.append(profile_model(model,experiment))
    if args.profile_only:return
    choice=choose_model(rows)
    unload_all()
    for n in [1,N_PARALLEL]:print(parallel_test(choice['model'],n),flush=True)
    card=save_summary()
    if not (RESULTS/'langchain_response.json').exists():print(langchain_call(card['model']),flush=True)
    unload_all();print('Lab1 complete:',RESULTS,flush=True)

if __name__=='__main__':main()
