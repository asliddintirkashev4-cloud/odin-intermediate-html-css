"""Run actual CPU Ollama experiments for P2; save every completed record.

Gold labels are accessed only by evaluation/report functions. Prompts receive
only raw logs, shared policies/aliases and retrieved source documents.
"""
from pathlib import Path
import argparse, csv, hashlib, json, os, random, sys, time
from p2_metrics import format_context, word_limit_ok, escalation_exact, micro_f1, citation_valid, field_matches, index_records, validate_judge_records, checks

HERE = Path(__file__).resolve().parent
COURSE = HERE.parent
DATA = Path(os.environ.get('GENAI_DATA', COURSE/'data/chaoscorp'))
RESULTS = Path(os.environ.get('GENAI_P2_RESULTS',os.environ.get('GENAI_RESULTS',HERE/'results'))); RESULTS.mkdir(parents=True,exist_ok=True)
MODEL = os.environ.get('GENAI_MODEL','qwen3:1.7b-q4_K_M')
URL = os.environ.get('GENAI_OLLAMA_URL','http://127.0.0.1:11434')
TRACK = os.environ.get('GENAI_TRACK','CPU').upper()
if TRACK not in {'CPU','GPU'}:raise ValueError('GENAI_TRACK must be CPU or GPU')
K = 3 if TRACK=='CPU' else 4
NUM_CTX = 2048 if TRACK=='CPU' else 4096
NUM_PREDICT = 200 if TRACK=='CPU' else 512
NUM_GPU = int(os.environ.get('GENAI_NUM_GPU','0' if TRACK=='CPU' else '99'))

def dump(path, obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

def read_jsonl(path):
    p=Path(path)
    return [json.loads(l) for l in p.read_text().splitlines() if l.strip()] if p.exists() else []

def append_jsonl(path, row):
    with Path(path).open('a') as f: f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())

def fingerprint(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True).encode()).hexdigest()[:16]

def load_data():
    incidents=sorted(json.loads((DATA/'incidents_test.json').read_text()),key=lambda r:r['incident_key'])
    if TRACK=='CPU':incidents=incidents[:12]
    services=json.loads((DATA/'services.json').read_text())['services']
    policies='\n\n'.join((DATA/'policies'/f).read_text() for f in ['policy_severity.md','policy_escalation.md'])
    return incidents,services,policies

INCIDENTS,SERVICES,POLICIES=load_data()
ALIASES='\n'.join(f"{s['service_name']}: {', '.join(s['aliases'])}" for s in SERVICES)
# Remove only Markdown decoration and document IDs. Keep every policy rule.
POLICY_TEXT='\n'.join(line.replace('**','').strip() for line in POLICIES.splitlines()
                      if line.strip() and not line.startswith(('#','doc_id:','|---')))
LENGTH_RULES=('Keep summary and probable_cause within five words each, steps within four words. Use exactly three steps. Write compact JSON without indentation or spaces outside quoted strings to fit the CPU token budget.' if TRACK=='CPU' else 'Keep summary, probable_cause and each recommended step at most twelve words. Use three to six recommended steps.')
SYSTEM_PROMPT=f'''You are the Chaos Corp incident triage assistant. Produce one triage record.
Apply these policies exactly:
{POLICY_TEXT}
Canonical service names and aliases:
{ALIASES}
Rules:
- {LENGTH_RULES}
- Cite one relevant provided [doc_id | chunk_id] pair. Without excerpts use [].
- Escalation targets form a list, possibly empty. Apply every matching rule.
- Use null for an incident ID absent from the log.
- Report uncertain causes as uncertain rather than claiming confirmation.
- Return the requested JSON record without explanatory prose.'''

def models():
    from typing import Literal
    from pydantic import BaseModel, Field, ConfigDict, create_model, field_validator
    class Citation(BaseModel):
        model_config=ConfigDict(extra='forbid')
        doc_id:str
        chunk_id:str
    class Triage(BaseModel):
        model_config=ConfigDict(extra='forbid')
        incident_id:int|None
        severity:Literal['High','Medium','Low']
        service_name:Literal[tuple([s['service_name'] for s in SERVICES]+['UNKNOWN'])]
        summary:str
        probable_cause:str
        recommended_steps:list[str]=Field(min_length=3,max_length=6)
        citations:list[Citation]
        escalation_targets:list[Literal['SRE_ONCALL','DB_ONCALL','SECURITY_ONCALL','FINOPS']]
        confidence:float=Field(ge=0,le=1)
        @field_validator('escalation_targets')
        @classmethod
        def unique_targets(cls,value):
            if len(value)!=len(set(value)):raise ValueError('duplicate escalation target')
            return value
    class Grounding(BaseModel):
        model_config=ConfigDict(extra='forbid')
        supported:bool
        evidence_quote:str
    return Triage,Grounding

def llm_for(schema,include_raw=False):
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_ollama import ChatOllama
    llm=ChatOllama(model=MODEL,base_url=URL,temperature=0,seed=42,num_ctx=NUM_CTX,num_predict=NUM_PREDICT,num_gpu=NUM_GPU,reasoning=False)
    return ChatPromptTemplate.from_messages([('system','{system}'),('human','{user}')]) | llm.with_structured_output(schema,method='json_schema',include_raw=include_raw)

def best_config():
    p=Path(os.environ.get('GENAI_P1_BEST_CONFIG',COURSE/'p1/results/p1_best_config.json'))
    if not p.exists():raise RuntimeError(f'Complete P1 first: missing {p}')
    return json.loads(p.read_text())

def get_retriever(cfg):
    sys.path.insert(0,str(COURSE/'p1'))
    from p1_retriever import Retriever
    return Retriever(data_path=DATA,chunking=cfg['chunking'],own_size=cfg.get('own_size',350),own_overlap=cfg.get('own_overlap',60),model=MODEL,result_dir=RESULTS/'retriever_cache')

def config_for(name,cfg,k,extra):
    return {'arm':name,'model':MODEL,'track':TRACK,'num_ctx':NUM_CTX,'num_predict':NUM_PREDICT,'num_gpu':NUM_GPU,'seed':42,'temperature':0,
            'dataset_sha256':hashlib.sha256((DATA/'incidents_test.json').read_bytes()).hexdigest(),
            'incident_keys':[i['incident_key'] for i in INCIDENTS], 'retriever_config':cfg,'k':k,
            'system_prompt_sha256':hashlib.sha256((SYSTEM_PROMPT+extra).encode()).hexdigest()}

def run_arm(name,cfg,k=None,extra=''):
    k=K if k is None else k
    Triage,_=models();chain=llm_for(Triage,include_raw=True)
    conf=config_for(name,cfg,k,extra);run_id=fingerprint(conf)
    path=RESULTS/f'{name}.jsonl';existing=read_jsonl(path)
    if any(r.get('run_id')!=run_id for r in existing):raise RuntimeError(f'{path}: stale config; archive it before rerunning.')
    dump(RESULTS/f'{name}_config.json',dict(conf,run_id=run_id))
    done=index_records(existing,name)
    retriever=get_retriever(cfg) if name!='baseline' else None
    for inc in INCIDENTS:
        key=inc['incident_key']
        if key in done:continue
        started=time.perf_counter();rt0=started
        chunks=retriever.retrieve_for_incident(inc['raw_log'],k=k,use_filter=cfg['use_filter']) if retriever else []
        retrieval_latency=time.perf_counter()-rt0
        chunks=[{f:c[f] for f in ['doc_id','chunk_id','section_ids','text']} for c in chunks]
        user='Incident log:\n'+inc['raw_log']
        if chunks:user+='\n\nRunbook excerpts:\n'+format_context(chunks)
        rec=None;attempts=[];t0=time.perf_counter()
        attempt_user=user
        for attempt in range(2):
            raw_response=None
            try:
                answer=chain.invoke({'system':SYSTEM_PROMPT+extra,'user':attempt_user})
                raw=answer.get('raw')
                raw_response={'content':raw.content,'response_metadata':raw.response_metadata,'usage_metadata':raw.usage_metadata} if raw else None
                if answer.get('parsing_error') is not None:
                    raise ValueError(str(answer['parsing_error']))
                candidate=answer['parsed'].model_dump()
                if not word_limit_ok(candidate):
                    attempts.append({'attempt':attempt+1,'valid':False,'error':'word-limit or step-count validation failed','candidate':candidate,'raw_response':raw_response})
                    attempt_user=user+'\n\nPrevious response failed length validation. Keep three very short steps, each under twelve words, and the summary and cause under twelve words.'
                    continue
                rec=candidate;attempts.append({'attempt':attempt+1,'valid':True,'raw_response':raw_response});break
            except Exception as e:
                attempts.append({'attempt':attempt+1,'valid':False,'error':str(e)[:500],'raw_response':raw_response})
                attempt_user=user+'\n\nPrevious response did not validate. Return a compact complete JSON record with three short steps.'
        row={'incident_key':key,'run_id':run_id,'latency_s':round(time.perf_counter()-t0,4),
             'retrieval_latency_s':round(retrieval_latency,4),'end_to_end_latency_s':round(time.perf_counter()-started,4),
             'output':rec,'error':None if rec else attempts[-1].get('error'),'attempts':attempts,'retrieved':chunks}
        append_jsonl(path,row)
        if not (RESULTS/'runtime_environment.json').exists():
            import importlib.metadata, platform, subprocess, requests
            gpu=subprocess.run(['nvidia-smi','--query-gpu=name,memory.total','--format=csv,noheader'],capture_output=True,text=True).stdout.strip() if __import__('shutil').which('nvidia-smi') else 'not available'
            try:loaded=requests.get(URL+'/api/ps',timeout=10).json()
            except Exception as e:loaded={'error':str(e)}
            try:
                tags=requests.get(URL+'/api/tags',timeout=10).json().get('models',[])
                model_versions=[m for m in tags if m.get('name') in {MODEL,'nomic-embed-text','nomic-embed-text:latest'}]
            except Exception as e:model_versions={'error':str(e)}
            packages={name:importlib.metadata.version(name) for name in ['requests','numpy','pandas','pydantic','faiss-cpu','langchain','langchain-core','langchain-community','langchain-ollama']}
            dump(RESULTS/'runtime_environment.json',{'platform':platform.platform(),'python':platform.python_version(),'track':TRACK,'gpu_query':gpu,'loaded_models':loaded,'model_versions':model_versions,'packages':packages})
        print(name,key,'valid' if rec else 'INVALID',row['end_to_end_latency_s'],'s',flush=True)
    return index_records(read_jsonl(path),name)

def judge_call(kind, schema, system, user, version):
    started=time.perf_counter()
    record={'kind':kind,'judge_version':version,'model':MODEL,'started_unix_s':time.time(),
            'prompt_sha256':fingerprint({'system':system,'user':user}),
            'system':system,'user':user}
    try:
        answer=llm_for(schema,include_raw=True).invoke({'system':system,'user':user})
        raw=answer.get('raw')
        record['raw_response']={'content':raw.content,'response_metadata':raw.response_metadata,'usage_metadata':raw.usage_metadata} if raw else None
        if answer.get('parsing_error') is not None:raise ValueError(str(answer['parsing_error']))
        parsed=answer['parsed'].model_dump()
        record['parsed']=parsed
        return parsed
    except Exception as e:
        record['error']=str(e)
        raise
    finally:
        record['wall_s']=time.perf_counter()-started
        append_jsonl(RESULTS/'judge_calls.jsonl',record)

def judge_cause(out,version=1):
    from typing import Literal
    from pydantic import create_model
    causes=next((s['causes'] for s in SERVICES if s['service_name']==out['service_name']),{})
    Choice=create_model('CauseChoice',cause_id=(Literal[tuple(list(causes)+['other'])],...),justification=(str,...))
    system="Map only the stated probable cause to the closest listed cause ID. If no listed cause fits, choose other. Do not infer a cause that was not stated. Keep the justification within twenty-five words.\n"+json.dumps(causes)
    if version>1:system+='\nLexical overlap alone is insufficient. Match the actual mechanism, not a symptom. Uncertain wording can still identify a listed mechanism. Otherwise choose other.'
    return judge_call('cause',Choice,system,out['probable_cause'],version)

def judge_step(step,texts,version=1):
    _,Grounding=models()
    system='Does the cited runbook text support this recommended step? supported=true only if the text explicitly recommends the action or a clearly equivalent action. Quote the shortest exact supporting passage, at most thirty words. Without supporting text, use supported=false and evidence_quote="".'
    if version>1:system+='\nDo not treat a symptom, cause, or service description as a recommended action. Verify that quoted words actually occur in the supplied text. A broader or riskier action is not supported by a narrower instruction.'
    return judge_call('grounding',Grounding,system,f'STEP: {step}\n\nCITED TEXT:\n'+'\n---\n'.join(texts or ['(no text cited)']),version)

def judge_arm(arm,version=1):
    rows=read_jsonl(RESULTS/f'{arm}.jsonl');path=RESULTS/f'judged_{arm}.jsonl'
    if version>1:path=RESULTS/f'judged_{arm}_v{version}.jsonl'
    source=index_records(rows,arm)
    existing=read_jsonl(path);done=index_records(existing,f'{arm} judges')
    validate_judge_records(arm,source,done,version,require_complete=False)
    for row in rows:
        if row['incident_key'] in done or not row['output']:continue
        out=row['output'];j={'incident_key':row['incident_key'],'run_id':row['run_id'],'judge_version':version}
        try:
            j['cause']=judge_cause(out,version)
            if arm!='baseline':
                cited={(c['doc_id'],c['chunk_id']) for c in out['citations']}
                texts=[c['text'] for c in row['retrieved'] if (c['doc_id'],c['chunk_id']) in cited]
                j['steps']=[{'step':s,**judge_step(s,texts,version)} for s in out['recommended_steps']]
            append_jsonl(path,j);print('judge',arm,row['incident_key'],flush=True)
        except Exception as e:
            append_jsonl(RESULTS/'judge_failures.jsonl',{'arm':arm,'incident_key':row['incident_key'],'version':version,'error':str(e)[:1000]})
            raise
    judged=index_records(read_jsonl(path),f'{arm} judges')
    validate_judge_records(arm,source,judged,version)
    return judged

def load_arms():
    return {arm:index_records(read_jsonl(RESULTS/f'{arm}.jsonl'),arm) for arm in ['baseline','rag','rag_mine'] if (RESULTS/f'{arm}.jsonl').exists()}

def chosen_judges(arm):
    manifest=RESULTS/'judge_review.json'
    version=json.loads(manifest.read_text()).get('selected_judge_version',1) if manifest.exists() else 1
    suffix=f'_v{version}' if version>1 else ''
    judged=index_records(read_jsonl(RESULTS/f'judged_{arm}{suffix}.jsonl'),f'{arm} judges')
    source=index_records(read_jsonl(RESULTS/f'{arm}.jsonl'),arm)
    validate_judge_records(arm,source,judged,version,require_complete=False)
    return judged

def metrics(arm,rows,judged):
    gold={i['incident_key']:i['gold'] for i in INCIDENTS}  # evaluation only
    keys=[i['incident_key'] for i in INCIDENTS]
    assert set(rows)==set(keys),f'{arm}: incomplete actual run'
    validate_judge_records(arm,rows,judged)
    outs={k:rows[k]['output'] for k in keys}
    acc=lambda field:100*sum(outs[k] is not None and outs[k][field]==gold[k][field] for k in keys)/len(keys)
    causekeys=[k for k in keys if gold[k]['cause_id'] is not None]
    steps=[s for j in judged.values() for s in j.get('steps',[])]
    return {'valid output %':100*sum(o is not None for o in outs.values())/len(keys),
        'severity acc %':acc('severity'),'service acc %':acc('service_name'),
        'escalation exact %':100*sum(outs[k] is not None and escalation_exact(outs[k]['escalation_targets'],gold[k]['escalation_targets']) for k in keys)/len(keys),
        'escalation micro-F1':micro_f1([((outs[k] or {}).get('escalation_targets',[]),gold[k]['escalation_targets']) for k in keys]),
        'cause acc % (judge)':100*sum(judged.get(k,{}).get('cause',{}).get('cause_id')==gold[k]['cause_id'] for k in causekeys)/max(1,len(causekeys)),
        'word limits ok %':100*sum(word_limit_ok(o) for o in outs.values())/len(keys),
        'mean generation latency s':sum(rows[k]['latency_s'] for k in keys)/len(keys),
        'mean end-to-end latency s':sum(rows[k]['end_to_end_latency_s'] for k in keys)/len(keys),
        'citation valid %':100*sum(citation_valid(rows[k]) for k in keys)/len(keys) if arm!='baseline' else None,
        'steps grounded % (judge)':100*sum(s['supported'] for s in steps)/max(1,len(steps)) if arm!='baseline' else None,
        'judged causes':len(judged),'judged steps':len(steps)}

def review_sample():
    rows=load_arms()['rag'];judged=chosen_judges('rag');rng=random.Random(7)
    causes=[(k,j['cause']) for k,j in judged.items()];steps=[(k,s) for k,j in judged.items() for s in j.get('steps',[])]
    rng.shuffle(causes);rng.shuffle(steps)
    sample=[]
    for kind,items in [('cause',causes[:5]),('step',steps[:5])]:
        for key,decision in items:
            r=rows[key];out=r['output'];cited={(c['doc_id'],c['chunk_id']) for c in out['citations']}
            sample.append({'number':len(sample)+1,'kind':kind,'incident_key':key,'service_name':out['service_name'],
                'probable_cause':out['probable_cause'],'decision':decision,
                'allowed_causes':next((s['causes'] for s in SERVICES if s['service_name']==out['service_name']),{}),
                'cited_chunks':[c for c in r['retrieved'] if (c['doc_id'],c['chunk_id']) in cited]})
    assert len(sample)==10,'Need actual 5 cause and 5 step decisions'
    dump(RESULTS/'judge_sample_to_review.json',sample)
    print('Review actual decisions in',RESULTS/'judge_sample_to_review.json')

def analyse():
    arms=load_arms();gold={i['incident_key']:i['gold'] for i in INCIDENTS}
    summary={a:metrics(a,rows,chosen_judges(a)) for a,rows in arms.items()};dump(RESULTS/'metrics.json',summary)
    errors=[];diff=[]
    for key,row in arms['rag'].items():
        g=gold[key];out=row['output'] or {}
        got={(c['doc_id'],sec) for c in row['retrieved'] for sec in c['section_ids']}
        gs=[tuple(s.split('#')) for s in g['gold_sections']];found=[f'{d}#{s}' for d,s in gs if (d,s) in got];missing=[f'{d}#{s}' for d,s in gs if (d,s) not in got]
        for field in ['severity','service_name','escalation_targets']:
            pred=out.get(field);target=g[field]
            wrong=not field_matches(row['output'],field,target)
            if wrong:
                kind='invalid output' if row['output'] is None else 'retrieval' if not found else 'retrieval (escalation section missing)' if field=='escalation_targets' and any(s.endswith('#s6_escalation') for s in missing) else 'generation'
                errors.append({'incident_key':key,'field':field,'predicted':pred,'gold':target,'hard_case_tags':g['hard_case_tags'],
                    'retrieved_chunks':[{'doc_id':c['doc_id'],'chunk_id':c['chunk_id'],'section_ids':c['section_ids']} for c in row['retrieved']],
                    'gold_sections_retrieved':found,'gold_sections_missing':missing,'suggested_failure_type':kind,'diagnosis':'Needs evidence review before final discussion.'})
        def correct(arm):
            o=arms[arm][key]['output']
            return sum(field_matches(o,field,g[field]) for field in ['severity','service_name','escalation_targets'])
        diff.append({'incident_key':key,'baseline_correct_fields':correct('baseline'),'rag_correct_fields':correct('rag'),'change':correct('rag')-correct('baseline')})
    dump(RESULTS/'errors_to_analyse.json',errors);dump(RESULTS/'helped_hurt_candidates.json',diff)
    print(json.dumps(summary,indent=2))

def improvement():
    plan=RESULTS/'improvement_plan.json'
    if not plan.exists():raise RuntimeError('Write improvement_plan.json BEFORE the third run, from actual baseline/RAG errors.')
    p=json.loads(plan.read_text());cfg=best_config();k=K;extra=''
    change=p['change'];assert change in ['k','service_filter','extra_rule'] and p.get('prediction')
    if change=='k':k=int(p['value']);assert k!=K
    elif change=='service_filter':cfg={**cfg,'use_filter':bool(p['value'])};assert cfg['use_filter']!=best_config()['use_filter']
    else:extra='\n- '+str(p['value']);assert str(p['value']).strip()
    run_arm('rag_mine',cfg,k,extra)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['check','arms','judges','sample','analyse','improvement','all'],default='check');parser.add_argument('--judge-version',type=int,default=1);args=parser.parse_args()
    print(checks())
    if args.stage=='check':return
    if args.stage in ['arms','all']:
        cfg=best_config();run_arm('baseline',cfg);run_arm('rag',cfg)
    if args.stage in ['judges','all']:
        for arm in load_arms():judge_arm(arm,args.judge_version)
    if args.stage in ['sample','all']:review_sample()
    if args.stage=='improvement':improvement()
    if args.stage in ['analyse','all']:analyse()

if __name__=='__main__':main()
