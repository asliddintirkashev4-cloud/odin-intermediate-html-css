"""Deterministic regression checks using real saved P2 evidence; no model calls."""
from copy import deepcopy
from pathlib import Path
import ast
import hashlib
import json
import tempfile
import time
import unittest
from statistics import fmean
from unittest.mock import patch

import run_p2 as run


class JudgeEvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = run.load_arms()['rag']
        cls.judges = run.chosen_judges('rag')
        cls.valid_key = next(k for k, row in cls.rows.items() if row['output'])

    def test_actual_metric_values_independently(self):
        gold = {inc['incident_key']: inc['gold'] for inc in run.INCIDENTS}
        for arm, rows in run.load_arms().items():
            judged = run.chosen_judges(arm)
            got = run.metrics(arm, rows, judged)
            n = len(gold)
            for field, metric in [('severity', 'severity acc %'), ('service_name', 'service acc %')]:
                expected = sum(row['output'] is not None and row['output'][field] == gold[k][field]
                               for k, row in rows.items()) * 100 / n
                self.assertAlmostEqual(got[metric], expected)
            eligible = [k for k in gold if gold[k]['cause_id'] is not None]
            expected = sum(judged.get(k, {}).get('cause', {}).get('cause_id') == gold[k]['cause_id']
                           for k in eligible) * 100 / len(eligible)
            self.assertAlmostEqual(got['cause acc % (judge)'], expected)
            expected_exact = sum(row['output'] is not None and
                                 set(row['output']['escalation_targets']) == set(gold[k]['escalation_targets'])
                                 for k, row in rows.items()) * 100 / n
            self.assertAlmostEqual(got['escalation exact %'], expected_exact)
            self.assertAlmostEqual(got['valid output %'], sum(row['output'] is not None for row in rows.values()) * 100 / n)
            compliant = 0
            for row in rows.values():
                out = row['output']
                if out is None:
                    continue
                phrases = [out['summary'], out['probable_cause'], *out['recommended_steps']]
                compliant += 3 <= len(out['recommended_steps']) <= 6 and all(1 <= len(s.split()) <= 12 for s in phrases)
                self.assertEqual(json.loads(row['attempts'][-1]['raw_response']['content']), out)
            self.assertAlmostEqual(got['word limits ok %'], compliant * 100 / n)
            self.assertAlmostEqual(got['mean generation latency s'], fmean(row['latency_s'] for row in rows.values()))
            self.assertAlmostEqual(got['mean end-to-end latency s'], fmean(row['end_to_end_latency_s'] for row in rows.values()))
            if arm != 'baseline':
                valid_citations = 0
                for row in rows.values():
                    refs = row['output']['citations'] if row['output'] else []
                    retrieved = {(c['doc_id'], c['chunk_id']) for c in row['retrieved']}
                    valid_citations += bool(refs) and all((c['doc_id'], c['chunk_id']) in retrieved for c in refs)
                self.assertAlmostEqual(got['citation valid %'], valid_citations * 100 / n)
                steps = [step for judgment in judged.values() for step in judgment['steps']]
                self.assertAlmostEqual(got['steps grounded % (judge)'], sum(s['supported'] for s in steps) * 100 / len(steps))
            tp = fp = fn = 0
            for k, row in rows.items():
                pred = set(row['output']['escalation_targets']) if row['output'] else set()
                target = set(gold[k]['escalation_targets'])
                tp += len(pred & target); fp += len(pred - target); fn += len(target - pred)
            self.assertAlmostEqual(got['escalation micro-F1'], 2*tp/(2*tp+fp+fn))

    def test_metrics_reject_missing_judge(self):
        judged = deepcopy(self.judges)
        judged.pop(self.valid_key)
        with self.assertRaisesRegex(ValueError, 'judge|Judge'):
            run.metrics('rag', self.rows, judged)

    def test_metrics_reject_stale_source(self):
        judged = deepcopy(self.judges)
        judged[self.valid_key]['run_id'] = 'an-earlier-source-run'
        with self.assertRaisesRegex(ValueError, 'judge|Judge'):
            run.metrics('rag', self.rows, judged)

    def test_metrics_reject_incomplete_steps(self):
        judged = deepcopy(self.judges)
        judged[self.valid_key]['steps'].pop()
        with self.assertRaisesRegex(ValueError, 'judge|Judge'):
            run.metrics('rag', self.rows, judged)

    def test_resume_rejects_stale_judges_before_calling_model(self):
        row = deepcopy(self.rows[self.valid_key])
        judge = deepcopy(self.judges[self.valid_key])
        judge['run_id'] = 'an-earlier-source-run'
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            for name, record in [('rag', row), ('judged_rag', judge)]:
                (folder / (name + '.jsonl')).write_text(json.dumps(record) + '\n')
            with patch.object(run, 'RESULTS', folder), patch.object(run, 'judge_cause') as call:
                with self.assertRaisesRegex(ValueError, 'judge|Judge'):
                    run.judge_arm('rag')
                call.assert_not_called()

    def test_resume_rejects_wrong_judge_version(self):
        row = deepcopy(self.rows[self.valid_key])
        judge = deepcopy(self.judges[self.valid_key])
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            (folder / 'rag.jsonl').write_text(json.dumps(row) + '\n')
            (folder / 'judged_rag_v2.jsonl').write_text(json.dumps(judge) + '\n')
            with patch.object(run, 'RESULTS', folder), patch.object(run, 'judge_cause') as call:
                with self.assertRaisesRegex(ValueError, 'judge|Judge'):
                    run.judge_arm('rag', version=2)
                call.assert_not_called()

    def test_selected_judge_version_is_checked(self):
        row = deepcopy(self.rows[self.valid_key])
        judge = deepcopy(self.judges[self.valid_key])
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            (folder / 'judge_review.json').write_text(json.dumps({'selected_judge_version': 2}))
            (folder / 'rag.jsonl').write_text(json.dumps(row) + '\n')
            (folder / 'judged_rag_v2.jsonl').write_text(json.dumps(judge) + '\n')
            with patch.object(run, 'RESULTS', folder):
                with self.assertRaisesRegex(ValueError, 'judge|Judge'):
                    run.chosen_judges('rag')

    def test_duplicate_source_evidence_is_rejected(self):
        row = self.rows[self.valid_key]
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            run.index_records([row, row], 'rag')

    def test_notebook_resume_rejects_changed_prompt(self):
        # Exercise the notebook's actual fresh-run implementation, not a copy.
        folder = Path(__file__).parent
        source = next(folder / name for name in ['P2_rag_evaluation_Asliddin.ipynb',
                                                 'P2_rag_evaluation_executed.ipynb']
                      if (folder / name).exists())
        notebook = json.loads(source.read_text())
        cell = next(c for c in notebook['cells'] if 'source' in c and
                    'def run_arm(name, use_rag):' in ''.join(c['source']))
        tree = ast.parse(''.join(cell['source']))
        functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
        namespace = dict(vars(run), hashlib=hashlib, json=json, time=time,
                         RETRIEVER_CONFIG=run.best_config(), USE_FILTER=run.best_config()['use_filter'],
                         SYSTEM_PROMPT=run.SYSTEM_PROMPT + '\nA changed rule.')
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            (folder / 'rag.jsonl').write_text((run.RESULTS / 'rag.jsonl').read_text())
            namespace['RESULTS'] = folder
            exec(compile(ast.Module(body=functions, type_ignores=[]), 'notebook-resume', 'exec'), namespace)
            with self.assertRaisesRegex(ValueError, 'stale experiment configuration'):
                namespace['run_arm']('rag', True)


if __name__ == '__main__':
    unittest.main()
