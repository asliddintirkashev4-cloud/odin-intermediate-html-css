"""Pure evaluation helpers for the P2 controlled RAG comparison."""

def format_context(chunks):
    return "\n\n".join(f"[{c['doc_id']} | {c['chunk_id']}]\n{c['text']}" for c in chunks)

def word_limit_ok(out):
    if not out or not isinstance(out.get('summary'), str) or not isinstance(out.get('probable_cause'), str):
        return False
    steps = out.get('recommended_steps', [])
    return (isinstance(steps, list) and 3 <= len(steps) <= 6
            and all(isinstance(s, str) and 0 < len(s.split()) <= 12
                    for s in [out['summary'], out['probable_cause'], *steps]))

def escalation_exact(pred, gold):
    return int(set(pred or []) == set(gold or []))

def micro_f1(pairs):
    tp = fp = fn = 0
    for pred, gold in pairs:
        pred, gold = set(pred or []), set(gold or [])
        tp += len(pred & gold); fp += len(pred - gold); fn += len(gold - pred)
    return 1.0 if tp + fp + fn == 0 else 2 * tp / (2 * tp + fp + fn)

def citation_valid(record):
    out = record.get('output')
    if not out or not out.get('citations'):
        return False
    retrieved = {(c['doc_id'], c['chunk_id']) for c in record.get('retrieved', [])}
    return all((c['doc_id'], c['chunk_id']) in retrieved for c in out['citations'])

def field_matches(output, field, expected):
    """An absent/invalid record never earns a correct field, even for []."""
    if output is None:
        return False
    predicted = output.get(field)
    if field == 'escalation_targets':
        return isinstance(predicted, list) and set(predicted) == set(expected)
    return predicted == expected

def index_records(records, label):
    """Do not silently collapse duplicate evidence rows by incident key."""
    indexed = {}
    for record in records:
        key = record['incident_key']
        if key in indexed:
            raise ValueError(f'{label}: duplicate incident {key}')
        indexed[key] = record
    return indexed

def validate_judge_records(arm, rows, judged, expected_version=None, require_complete=True):
    """A score must use complete judgments from the same source experiment."""
    valid_keys = {key for key, row in rows.items() if row['output'] is not None}
    if not set(judged) <= valid_keys:
        raise ValueError(f'{arm}: judge records reference absent or invalid outputs')
    if require_complete and set(judged) != valid_keys:
        raise ValueError(f'{arm}: missing judge records for {sorted(valid_keys - set(judged))}')
    versions = set()
    for key, judgment in judged.items():
        row = rows[key]
        if not row.get('run_id') or judgment.get('run_id') != row['run_id']:
            raise ValueError(f'{arm}/{key}: stale judge source run_id')
        version = judgment.get('judge_version')
        if not isinstance(version, int) or version < 1:
            raise ValueError(f'{arm}/{key}: missing judge version')
        versions.add(version)
        if expected_version is not None and version != expected_version:
            raise ValueError(f'{arm}/{key}: stale judge version {version}, expected {expected_version}')
        cause = judgment.get('cause')
        if not isinstance(cause, dict) or not isinstance(cause.get('cause_id'), str) or not isinstance(cause.get('justification'), str):
            raise ValueError(f'{arm}/{key}: incomplete cause judge record')
        steps = judgment.get('steps', [])
        expected_steps = row['output']['recommended_steps'] if arm != 'baseline' else []
        if (not isinstance(steps, list) or len(steps) != len(expected_steps)
                or any(s.get('step') != expected or type(s.get('supported')) is not bool
                       or not isinstance(s.get('evidence_quote'), str)
                       for s, expected in zip(steps, expected_steps))):
            raise ValueError(f'{arm}/{key}: incomplete or mismatched step judge records')
    if len(versions) > 1:
        raise ValueError(f'{arm}: mixed judge versions')

def checks():
    assert format_context([]) == ''
    ctx = format_context([{'doc_id':'d1','chunk_id':'d1#0','text':'alpha'}, {'doc_id':'d2','chunk_id':'d2#1','text':'beta'}])
    assert ctx == '[d1 | d1#0]\nalpha\n\n[d2 | d2#1]\nbeta'
    ok = {'summary':'short', 'probable_cause':'short cause', 'recommended_steps':['a','b','c']}
    assert word_limit_ok(ok) and not word_limit_ok(None)
    for bad in [dict(ok,summary='w '*13), dict(ok,recommended_steps=['a','b']), dict(ok,recommended_steps=['a','b','x '*13]), dict(ok,summary='')]:
        assert not word_limit_ok(bad)
    assert escalation_exact(['FINOPS','SRE_ONCALL'],['SRE_ONCALL','FINOPS']) == 1
    assert escalation_exact([],['SRE_ONCALL']) == 0
    assert abs(micro_f1([(['SRE_ONCALL'],['SRE_ONCALL','FINOPS']),([],[])]) - 2/3) < 1e-9
    assert micro_f1([([],[]),([],[])]) == 1 and micro_f1([(['FINOPS'],[])]) == 0
    rec={'output':{'citations':[{'doc_id':'d','chunk_id':'d#1'}]}, 'retrieved':[{'doc_id':'d','chunk_id':'d#1'}]}
    assert citation_valid(rec)
    assert not citation_valid(dict(rec,output={'citations':[{'doc_id':'x','chunk_id':'d#1'}]}))
    assert not citation_valid(dict(rec,output={'citations':[]}))
    assert not field_matches(None, 'escalation_targets', [])
    assert not field_matches({}, 'escalation_targets', [])
    assert field_matches({'escalation_targets': []}, 'escalation_targets', [])
    return 'Pure helper checks passed (format, word limits, set metrics, citation identity).'

if __name__ == '__main__':
    print(checks())
