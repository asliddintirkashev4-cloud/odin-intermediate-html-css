import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import l2_experiment as lab


class EvaluationTests(unittest.TestCase):
    def test_changed_log_cannot_reuse_same_incident_key(self):
        incident={'incident_key':'TEST','raw_log':'first log'}
        good=json.dumps({'incident_id':None,'severity':'Low','service_name':'UNKNOWN','summary':'No incident'})
        with tempfile.TemporaryDirectory() as temp, patch.object(lab,'chat',return_value=(good,{'message':{'content':good}})):
            lab.run_all(temp,'model',[incident],'SYSTEM')
            changed={**incident,'raw_log':'different evidence'}
            with self.assertRaisesRegex(ValueError,'configuration|identity|dataset'):
                lab.run_all(temp,'model',[changed],'SYSTEM')

    def test_gold_changes_do_not_enter_model_cache_identity(self):
        incident={'incident_key':'TEST','raw_log':'first log','gold':{'severity':'Low'}}
        good=json.dumps({'incident_id':None,'severity':'Low','service_name':'UNKNOWN','summary':'No incident'})
        with tempfile.TemporaryDirectory() as temp, patch.object(lab,'chat',return_value=(good,{'message':{'content':good}})) as chat:
            lab.run_all(temp,'model',[incident],'SYSTEM')
            chat.reset_mock()
            lab.run_all(temp,'model',[{**incident,'gold':{'severity':'High'}}],'SYSTEM')
            chat.assert_not_called()

    def test_cache_replay_does_not_overwrite_measurement_runtime(self):
        with tempfile.TemporaryDirectory() as temp, \
             patch.object(lab,'RESULTS',Path(temp)), \
             patch.object(lab,'load_data',return_value=([], 'SYSTEM')), \
             patch.object(lab,'check_ollama',return_value={'version':'new replay server'}), \
             patch.object(lab,'run_all'), patch.object(lab,'save_tables'):
            runtime=Path(temp)/'runtime.json'
            original='{"runtime":"original measured host","started_utc":"original"}'
            runtime.write_text(original)
            lab.run_experiments('main')
            self.assertEqual(runtime.read_text(),original)

    def test_invalid_output_is_wrong_even_when_gold_id_is_null(self):
        inc={"incident_key":"TEST", "gold":{"incident_id":None,"severity":"Low","service_name":"UNKNOWN","hard_case_tags":[]}}
        with tempfile.TemporaryDirectory() as temp:
            for name in lab.STRATEGY_NAMES:
                lab.append_jsonl(Path(temp)/f'{name}.jsonl',{"incident_key":"TEST","attempts":[{"schema_valid":False}],"final":None,"calls":1,"latency_s":1.0})
            metrics=lab.evaluate('A_retry',temp,[inc])
            self.assertEqual(metrics['incident_id acc %'],0)
            self.assertEqual(len(lab.error_table(temp,[inc])),9)

    def test_schema_and_word_limit_are_distinct(self):
        valid={"incident_id":None,"severity":"High","service_name":"UNKNOWN","summary":" ".join(['word']*13)}
        rec,error=lab.validate(json.dumps(valid))
        self.assertIsNone(error)
        self.assertFalse(lab.words_ok(rec))
        valid['extra']='not in schema'
        self.assertIsNone(lab.validate(json.dumps(valid))[0])

    def test_repair_keeps_complete_first_response_and_never_uses_gold(self):
        incident={"incident_key":"TEST","raw_log":"service=auth; latency increase", "gold":{"secret":"do not send"}}
        good=json.dumps({"incident_id":None,"severity":"Medium","service_name":"AuthServer","summary":"Login latency increased"})
        calls=[]
        def fake_chat(messages,model,fmt):
            calls.append(json.loads(json.dumps(messages)))
            raw='x'*600 if len(calls)==1 else good
            return raw,{"message":{"content":raw}}
        with patch.object(lab,'chat',side_effect=fake_chat):
            row=lab.run_strategy(incident,'model','A_retry','SYSTEM')
        self.assertEqual(row['calls'],2)
        self.assertEqual(len(row['attempts'][0]['raw']),600)
        self.assertIn('JSON was invalid',calls[1][-1]['content'])
        self.assertNotIn('do not send',json.dumps(calls))


if __name__=='__main__':
    unittest.main()
