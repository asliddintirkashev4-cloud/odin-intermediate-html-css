"""Lab 2: reproducible, resumable Ollama structured extraction measurements."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, Optional

import pandas as pd
import requests
from pydantic import BaseModel, ConfigDict, Field, ValidationError

HERE = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
DATA = Path(os.environ.get("GENAI_DATA", str(HERE.parent / "data" / "chaoscorp")))
RESULTS = Path(os.environ.get("GENAI_L2_RESULTS", str(HERE / "results")))
TRACK = os.environ.get("GENAI_TRACK", "CPU").upper()
MODEL = os.environ.get("GENAI_MODEL", "qwen3:4b-q4_K_M" if TRACK == "GPU" else "qwen3:1.7b-q4_K_M")
TINY_MODEL = "qwen3:0.6b-q4_K_M"
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434").rstrip("/")
OPTIONS = {"temperature": 0, "seed": 42, "num_ctx": 4096 if TRACK == "GPU" else 2048,
           "num_predict": 512 if TRACK == "GPU" else 200}
if TRACK == "CPU":
    OPTIONS["num_gpu"] = 0  # A local Mac must not silently use Metal for a declared CPU run.
else:
    OPTIONS["num_gpu"] = 99
IN_COLAB = bool(os.environ.get("COLAB_RELEASE_TAG") or os.environ.get("COLAB_GPU") or os.environ.get("GENAI_IN_COLAB"))
RUNTIME = os.environ.get("GENAI_RUNTIME", ("Google Colab " if IN_COLAB else "local ") + TRACK)
STRATEGY_NAMES = ("A_retry", "B_json_mode", "C_schema")

# SECTION helpers
def read_jsonl(path):
    if not Path(path).exists():
        return []
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def append_jsonl(path, record):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def pull(model):
    response = requests.post(OLLAMA_URL + "/api/pull", json={"model": model, "stream": False}, timeout=3600)
    response.raise_for_status()
    return response.json()


def check_ollama():
    response = requests.get(OLLAMA_URL + "/api/version", timeout=10)
    response.raise_for_status()
    return response.json()


def chat(messages, model, fmt=None):
    body = {"model": model, "messages": messages, "stream": False, "options": OPTIONS,
            "keep_alive": "10m"}
    if model.startswith("qwen3"):
        body["think"] = False
    if fmt is not None:
        body["format"] = fmt
    response = requests.post(OLLAMA_URL + "/api/chat", json=body, timeout=900)
    response.raise_for_status()
    full = response.json()
    return full["message"]["content"], full
# END helpers

# SECTION schema
ServiceName = Literal["PaymentGateway_v2", "EmailNotifier", "AuthServer", "DatabaseCluster", "Frontend_React",
                      "UserProfileDB", "SearchEngine", "payment-processor", "InventoryAPI", "Recommendations-AI", "UNKNOWN"]


class Extraction(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    incident_id: Optional[int] = Field(description="ID in the log, or null if there is none")
    severity: Literal["High", "Medium", "Low"]
    service_name: ServiceName
    summary: str = Field(description="at most 12 words")


def load_data():
    incidents = json.loads((DATA / "incidents_dev.json").read_text())
    guide = (DATA / "policies" / "policy_severity.md").read_text()
    services = json.loads((DATA / "services.json").read_text())["services"]
    service_lines = "\n".join(f"- {s['service_name']} (also called: {', '.join(s['aliases'])})" for s in services)
    system_prompt = f"""You extract incident records for Chaos Corp.
Apply this severity guide exactly (including the upward overrides):
{guide}

Valid service names (map aliases to the canonical name; use UNKNOWN if no service matches):
{service_lines}

Return JSON with exactly these fields: incident_id (integer or null), severity (High|Medium|Low), service_name, summary (at most 12 words).
Return only JSON without markdown or explanations."""
    assert len(incidents) == 15
    return incidents, system_prompt


def validate(text):
    try:
        return Extraction.model_validate_json(text), None
    except ValidationError as error:
        return None, str(error)


def words_ok(record):
    if isinstance(record, Extraction):
        record = record.model_dump()
    return record is not None and len(record["summary"].split()) <= 12
# END schema

# SECTION repair
def repair_message(error):
    return f"Your JSON was invalid: {error}. Return only corrected JSON, with no explanations or markdown."
# END repair

# SECTION strategies
def config_id(model, system_prompt):
    payload = {"model": model, "options": OPTIONS, "prompt": system_prompt,
               "schema": Extraction.model_json_schema(), "version": 1}
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()


def dataset_identity(incidents):
    """Cache only model inputs; gold labels remain evaluation-only."""
    inputs=[{'incident_key':row['incident_key'],'raw_log':row['raw_log']} for row in incidents]
    return hashlib.sha256(json.dumps(inputs,sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def ensure_dataset_identity(folder,incidents):
    path=Path(folder)/'dataset_manifest.json'
    expected={'version':1,'inputs_sha256':dataset_identity(incidents),
              'incident_keys':[row['incident_key'] for row in incidents]}
    if path.exists():
        if json.loads(path.read_text())['identity']!=expected:
            raise ValueError('Cached dataset identity differs; use a new results folder.')
    else:
        if any(read_jsonl(Path(folder)/f'{name}.jsonl') for name in STRATEGY_NAMES):
            raise ValueError('Legacy cached dataset has no identity manifest; audit it or use a new results folder.')
        path.write_text(json.dumps({'identity':expected,'established_utc':datetime.now(timezone.utc).isoformat(),
                                   'established_by':'before model calls'},indent=2))


def run_strategy(incident, model, strategy, system_prompt, call_log_path=None):
    if strategy not in STRATEGY_NAMES:
        raise ValueError(strategy)
    fmt = None if strategy == "A_retry" else ("json" if strategy == "B_json_mode" else Extraction.model_json_schema())
    max_retries = 1 if strategy == "C_schema" else 3
    # Only raw_log enters the model. Gold is reserved for evaluation below.
    messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": incident["raw_log"]}]
    attempts, final = [], None
    experiment_id = config_id(model, system_prompt)
    for attempt in range(1 + max_retries):
        started = time.perf_counter()
        full, raw, error, rec = None, None, None, None
        try:
            raw, full = chat(messages, model=model, fmt=fmt)
            rec, error = validate(raw)
        except (requests.RequestException, KeyError, ValueError) as failure:
            error = f"{type(failure).__name__}: {failure}"
        latency = time.perf_counter() - started
        entry = {"experiment_id": experiment_id, "model": model, "strategy": strategy,
                 "incident_key": incident["incident_key"], "attempt": attempt + 1,
                 "timestamp_utc": datetime.now(timezone.utc).isoformat(), "latency_s": latency,
                 "raw": raw, "error": error, "schema_valid": rec is not None,
                 "summary_words_ok": words_ok(rec), "response": full}
        attempts.append(entry)
        if call_log_path is not None:
            append_jsonl(call_log_path, entry)
        if rec is not None:
            final = rec.model_dump()
            break
        if raw is not None:
            messages.append({"role": "assistant", "content": raw})
        messages.append({"role": "user", "content": repair_message(error)})
    return {"experiment_id": experiment_id, "model": model, "strategy": strategy,
            "incident_key": incident["incident_key"], "attempts": attempts, "calls": len(attempts),
            "latency_s": sum(a["latency_s"] for a in attempts), "final": final}


def run_all(folder, model, incidents, system_prompt):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    ensure_dataset_identity(folder,incidents)
    experiment_id = config_id(model, system_prompt)
    for strategy in STRATEGY_NAMES:
        path = folder / f"{strategy}.jsonl"
        existing = read_jsonl(path)
        if any(row.get("experiment_id") != experiment_id for row in existing):
            raise ValueError(f"Cached configuration differs: {path}; use a new results folder.")
        done = {row["incident_key"] for row in existing}
        for inc in incidents:
            if inc["incident_key"] not in done:
                result = run_strategy(inc, model, strategy, system_prompt, folder / "calls.jsonl")
                append_jsonl(path, result)
                print(f"{model} {strategy} {inc['incident_key']}: calls={result['calls']}, valid={result['final'] is not None}", flush=True)
        print(strategy, "completed", len(read_jsonl(path)), "/", len(incidents), flush=True)
# END strategies

# SECTION evaluation
FIELDS = ("incident_id", "severity", "service_name")


def evaluate(strategy, folder, incidents):
    rows = read_jsonl(Path(folder) / f"{strategy}.jsonl")
    gold = {incident["incident_key"]: incident["gold"] for incident in incidents}
    n = len(incidents)
    if len(rows) != n or len({row["incident_key"] for row in rows}) != n:
        raise ValueError(f"Expected {n} unique results for {strategy}; found {len(rows)}")
    accuracy = {f: 100 * sum(row["final"] is not None and row["final"][f] == gold[row["incident_key"]][f]
                             for row in rows) / n for f in FIELDS}
    return {"strategy": strategy,
            "valid first try %": 100 * sum(row["attempts"][0]["schema_valid"] for row in rows) / n,
            "valid after retries %": 100 * sum(row["final"] is not None for row in rows) / n,
            "mean calls": sum(row["calls"] for row in rows) / n,
            "mean latency s": sum(row["latency_s"] for row in rows) / n,
            **{f"{f} acc %": value for f, value in accuracy.items()},
            "summary <=12 words %": 100 * sum(words_ok(row["final"]) for row in rows) / n}


def field_explanation(field, incident, predicted, valid):
    if not valid:
        return "No schema-valid final record; every target field counts as wrong."
    tags = incident["gold"]["hard_case_tags"]
    if field == "incident_id":
        if predicted is None and incident['gold']['incident_id'] is not None:
            return f"The output omits the explicit incident identifier {incident['gold']['incident_id']} present in the log."
        return "The record invents or misreads an incident identifier; missing IDs must remain null."
    if field == "severity":
        if "H2_contradictory_severity" in tags:
            return "The written label conflicts with impact; the severity guide's upward override takes priority."
        return "The severity does not follow the label mapping or no-label impact rules."
    if "H5_multi_service" in tags:
        return "Several services are mentioned; the output selects a different service from the one at fault."
    if "H4_ambiguous_service" in tags:
        return "The alias is not mapped to the correct canonical service."
    return "The selected canonical service does not match the service affected in the log."


def error_table(folder, incidents):
    errors = []
    by_key = {incident["incident_key"]: incident for incident in incidents}
    for strategy in STRATEGY_NAMES:
        for row in read_jsonl(Path(folder) / f"{strategy}.jsonl"):
            inc = by_key[row["incident_key"]]
            final, g = row["final"], inc["gold"]
            for field in FIELDS:
                predicted = final[field] if final is not None else None
                if final is None or predicted != g[field]:
                    errors.append({"strategy": strategy, "incident_key": inc["incident_key"],
                                   "field": field, "predicted": predicted, "gold": g[field],
                                   "valid_output": final is not None,
                                   "hard_case_tags": ", ".join(g["hard_case_tags"]),
                                   "explanation": field_explanation(field, inc, predicted, final is not None)})
    return pd.DataFrame(errors, columns=["strategy", "incident_key", "field", "predicted", "gold", "valid_output", "hard_case_tags", "explanation"])


def metric_table(folder, incidents):
    return pd.DataFrame([evaluate(name, folder, incidents) for name in STRATEGY_NAMES]).set_index("strategy").T


def summary_limit_violations(folder):
    rows = []
    for strategy in STRATEGY_NAMES:
        for row in read_jsonl(Path(folder) / f'{strategy}.jsonl'):
            final = row['final']
            if final is not None and not words_ok(final):
                rows.append({'strategy': strategy, 'incident_key': row['incident_key'],
                             'summary': final['summary'], 'word_count': len(final['summary'].split())})
    return pd.DataFrame(rows, columns=['strategy', 'incident_key', 'summary', 'word_count'])


def save_tables(folder, incidents):
    folder = Path(folder)
    metric_table(folder, incidents).to_csv(folder / "metrics.csv")
    error_table(folder, incidents).to_csv(folder / "errors.csv", index=False)
    summary_limit_violations(folder).to_csv(folder / 'summary_limit_violations.csv', index=False)
    calls = read_jsonl(folder / "calls.jsonl")
    pd.DataFrame([{k: v for k, v in call.items() if k != "response"} for call in calls]).to_csv(folder / "calls.csv", index=False)
# END evaluation


def analysis_answers(main_folder, stress_folder, incidents, model):
    """Build a factual draft from the completed measurements, never guessed numbers."""
    main = {name: evaluate(name, main_folder, incidents) for name in STRATEGY_NAMES}
    tiny = {name: evaluate(name, stress_folder, incidents) for name in STRATEGY_NAMES}
    a, b, c = (main[name] for name in STRATEGY_NAMES)
    errors = error_table(main_folder, incidents)
    tiny_errors = error_table(stress_folder, incidents)
    answers = [
        (f"I measured mean calls of {a['mean calls']:.2f} for A, {b['mean calls']:.2f} for B and {c['mean calls']:.2f} for C. "
         f"Their mean total latencies were {a['mean latency s']:.2f}, {b['mean latency s']:.2f} and {c['mean latency s']:.2f} seconds. "
         "I compare format guarantees with these measured costs rather than assuming constrained output is faster."),
    ]
    ranking = sorted(STRATEGY_NAMES, key=lambda name: sum(main[name][f'{f} acc %'] for f in FIELDS), reverse=True)
    best = ranking[0]
    tied = [name for name in ranking if sum(main[name][f'{f} acc %'] for f in FIELDS) == sum(main[best][f'{f} acc %'] for f in FIELDS)]
    accuracy = ", ".join(f"{name}: {main[name]['severity acc %']:.1f}% severity" for name in STRATEGY_NAMES)
    if len(errors):
        counts = errors["hard_case_tags"].str.split(", ").explode().value_counts()
        tag_text = ", ".join(f"{tag} ({count} wrong-field rows)" for tag, count in counts.head(2).items() if tag)
        if not tag_text:
            tag_text = "no hard-case tags: the observed mistakes were in untagged incidents"
    else:
        tag_text = "none, because I observed no wrong target fields"
    answers.append(f"By mean accuracy across the three evaluated fields, {', '.join(tied)} led. {accuracy}. The most common error tags were {tag_text}. Tags can overlap, so their counts are not independent cases.")
    valid_errors = errors[errors["valid_output"]] if len(errors) else errors
    if len(valid_errors):
        e = valid_errors.iloc[0]
        expected = e['gold'].item() if hasattr(e['gold'], 'item') else e['gold']
        predicted = e['predicted'].item() if hasattr(e['predicted'], 'item') else e['predicted']
        answers.append(f"In {e['incident_key']} with {e['strategy']}, valid JSON gave {e['field']}={predicted!r} instead of {expected!r}. {e['explanation']} Schema checks cannot detect this. I would add policy checks, provenance and human review for uncertain or high-impact incidents.")
    else:
        answers.append("I observed no valid-but-wrong target field with my main model in this run. I cannot provide an observed counterexample from that table. Schema validity still cannot establish factual correctness, so I would retain policy checks and human review for uncertain incidents.")
    answers.append("For a batch backend I would use schema-constrained C with explicit validation and a recorded failure queue. For an interactive chatbot I would also start with C to limit repair delays, but I would offer an honest fallback when extraction fails. The measured latencies, not the format alone, determine whether the interaction is acceptable.")
    tiny_valid = tiny_errors[tiny_errors["valid_output"]] if len(tiny_errors) else tiny_errors
    prefix = (f"With the tiny model, first-try validity was {tiny['A_retry']['valid first try %']:.1f}% for A, "
              f"{tiny['B_json_mode']['valid first try %']:.1f}% for B and {tiny['C_schema']['valid first try %']:.1f}% for C. ")
    if len(tiny_valid):
        e = tiny_valid.iloc[0]
        suffix = f"For example, {e['strategy']} returned {e['field']}={e['predicted']!r} for {e['incident_key']}, while gold was {e['gold']!r}. This is a content error that a valid format did not fix."
    else:
        suffix = "I observed no valid-but-wrong target fields in the tiny model table either. I report this result without inventing a failure example. The limited sample does not prove general correctness."
    answers.append(prefix + suffix)
    return answers


def run_experiments(only=None):
    incidents, system_prompt = load_data()
    RESULTS.mkdir(parents=True, exist_ok=True)
    metadata = {"runtime": RUNTIME, "track": TRACK, "platform": platform.platform(),
                "model": MODEL, "tiny_model": TINY_MODEL, "options": OPTIONS,
                "ollama": check_ollama(), "started_utc": datetime.now(timezone.utc).isoformat(),
                "data_sha256": hashlib.sha256((DATA / "incidents_dev.json").read_bytes()).hexdigest()}
    runtime_path=RESULTS/'runtime.json'
    if not runtime_path.exists():
        runtime_path.write_text(json.dumps(metadata,indent=2))
    if only != "stress":
        run_all(RESULTS / "main", MODEL, incidents, system_prompt)
        save_tables(RESULTS / "main", incidents)
    if only != "main":
        run_all(RESULTS / "stress_tiny", TINY_MODEL, incidents, system_prompt)
        save_tables(RESULTS / "stress_tiny", incidents)
    if only is None:
        answers = analysis_answers(RESULTS / "main", RESULTS / "stress_tiny", incidents, MODEL)
        (RESULTS / "analysis_answers.json").write_text(json.dumps(answers, ensure_ascii=False, indent=2))
    print("Saved real results to", RESULTS, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--only", choices=["main", "stress"])
    args = parser.parse_args()
    run_experiments(args.only)
